#!/usr/bin/env python

import os
import rospy
from std_msgs.msg import String
from Queue import Queue
import time

all_to_say = Queue()
SLEEP_SECS = 0.5    # sleep


# will store here what we have to say
def allThereIsToSay(data):
    global all_to_say

    # add what is there to say
    to_say = data.data
    all_to_say.put(to_say)


if __name__ == "__main__":

    # create node
    rospy.init_node('textToSpeechController', anonymous=True)

    # create subscriber to the user feedback topic
    feedbackSub = rospy.Subscriber('/hanoi/userFeedback', String, allThereIsToSay)

    while not rospy.is_shutdown():
        # while there is something to say
        if not all_to_say.empty():
            say_now = all_to_say.get()
            command = "espeak '{}'".format(say_now)
            os.system(command)

        time.sleep(SLEEP_SECS)

    # prevents program from exiting, allowing subscribers and publishers to keep operating
    rospy.spin()
