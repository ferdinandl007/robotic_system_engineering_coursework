#!/usr/bin/env python

import rospy
from std_msgs.msg import String
from std_msgs.msg import Int8

# initializations
feedback_string = "Good."


# will publish to speech node
feedbackPub = rospy.Publisher('/hanoi/userFeedback',String)


# will give the user positive feedback
def callbackMove(data):
    valid_move = data.data

    # if move is correct
    if valid_move == 1:
        print(feedback_string)
        rospy.loginfo("Good.")
        feedbackPub.publish(feedback_string)


if __name__ == "__main__":

    # create node
    rospy.init_node('correctMoveAlgorithm', anonymous=True)

    # create subscriber to the valid move topic
    validMoveSub = rospy.Subscriber('/hanoi/validMove', Int8, callbackMove)

    # prevents program from exiting, allowing subscribers and publishers to keep operating
    rospy.spin()
