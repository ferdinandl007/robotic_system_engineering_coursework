#!/usr/bin/env python

import rospy
import rostest
import unittest
from hanoi.msg import Moves
from hanoi.msg import FilteredBoard
from hanoi.msg import Disk
PKG="hanoi"



class testGameController(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # make disks to be used by test cases
        cls.disk_pink = Disk('pink', 1)
        cls.disk_red = Disk('red', 2)
        cls.disk_orange = Disk('orange', 3)
        cls.disk_yellow = Disk('yellow', 4)
        cls.disk_green = Disk('green', 5)
        cls.disk_dark_green = Disk('dark_green', 6)
        cls.disk_blue = Disk('blue', 7)
        cls.disk_dark_blue = Disk('dark_blue', 8)

        # hold moves
        cls.next_moves = None

        # create node
        rospy.init_node('gameControllerTEST', anonymous=True)

        # subscriber to moves
        cls.nextMoveSub = rospy.Subscriber('/hanoi/nextMove', Moves, cls.callbackMoves)

        # publisher to last valid board
        cls.lastValidPub = rospy.Publisher('/hanoi/lastValidBoard', FilteredBoard)

        # need to sleep to allow this node to subscribe
        rospy.sleep(2.0)


    @classmethod
    def callbackMoves(self, data):
        self.next_moves = data.moves


    # send a valid board
    def test_1(self):

        # construct a valid board configuration
        # left tower: orange, red, pink
        # middle tower: green, yellow
        # right tower: dark_blue, blue, dark_green
        # encoding: [2,2,2,1,1,0,0,0]
        board_valid = FilteredBoard()
        board_valid.left.append(self.disk_orange)
        board_valid.left.append(self.disk_red)
        board_valid.left.append(self.disk_pink)
        board_valid.middle.append(self.disk_green)
        board_valid.middle.append(self.disk_yellow)
        board_valid.right.append(self.disk_dark_blue)
        board_valid.right.append(self.disk_blue)
        board_valid.right.append(self.disk_dark_green)
        board_valid.encoded = [2,2,2,1,1,0,0,0]

        # publish valid board to topic and wait
        self.lastValidPub.publish(board_valid)
        rospy.sleep(2.0)

        # check if the first next move is one of the following:
        # 1) pink disk on yellow disk [from tower 0 to 1]
        # 2) pink disk on dark_green disk [from tower 0 to 2]
        # 3) yellow disk on dark_green disk [from tower 1 to 2]
        possible_valid_moves = [[0,1],[0,2],[1,2]]
        next_move = self.next_moves[0]
        move_elements = next_move.split(' ')
        orig = int(move_elements[3])
        dest = int(move_elements[5])
        output_move = [orig,dest]

        # check if solution is in possible valid moves
        self.assertTrue(output_move in possible_valid_moves, 'Incorrect next move (middle of game)')


    # send a valid board, resulting in game completion
    def test_2(self):

        # construct a valid board configuration
        # left tower:
        # middle tower: pink
        # right tower: orange, red
        # encoding: [2,2,1]
        board_valid = FilteredBoard()
        board_valid.middle.append(self.disk_pink)
        board_valid.right.append(self.disk_orange)
        board_valid.right.append(self.disk_red)
        board_valid.encoded = [2,2,1]

        # publish valid board to topic and wait
        self.lastValidPub.publish(board_valid)
        rospy.sleep(2.0)

        # check if the next move is one of the following:
        # 1) pink disk on red disk [from tower 1 to 2]
        # 2) pink disk on empty left tower [from tower 1 to 0]
        # 3) red disk on empty left tower [from tower 2 to 0]
        possible_valid_moves = [[1,2],[1,0],[2,0]]
        next_move = self.next_moves[0]
        move_elements = next_move.split(' ')
        orig = int(move_elements[3])
        dest = int(move_elements[5])
        output_move = [orig,dest]

        # check if solution is in possible valid moves
        self.assertTrue(output_move in possible_valid_moves, 'Incorrect next move (game end)')


    # send a an already complete game
    def test_3(self):

        # construct a valid board configuration
        # left tower:
        # middle tower:
        # right tower: orange, red, pink
        # encoding: [2,2,2]
        board_valid = FilteredBoard()
        board_valid.right.append(self.disk_orange)
        board_valid.right.append(self.disk_red)
        board_valid.right.append(self.disk_pink)
        board_valid.encoded = [2,2,2]

        # publish valid board to topic and wait
        self.lastValidPub.publish(board_valid)
        rospy.sleep(2.0)

        # check if any next move is sent
        next_move = self.next_moves
        done = len(self.next_moves) == 0
        self.assertTrue(done, 'Next move sent although game configuration is completed')


if __name__ == '__main__':
    rostest.rosrun(PKG, "test_game_controller", testGameController)