import sys
sys.path.insert(0,"../")
# insert the parent folder into the path of this test
import unittest
import numpy as np
import cv2
import blobFunctions as bf
opencv_2 = cv2.__version__.startswith('2')


# test with composed image
class testDiskDetectionComposed(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        # https://www.researchgate.net/figure/The-range-of-Hue-H-value-with-correspond-color_tbl1_330838912
        # H,S,V

        # define blobs
        cls.red_low = np.uint8([0, 100, 100])
        cls.red_up = np.uint8([6, 255, 255])
        cls.yellow_low = np.uint8([26, 100, 100])
        cls.yellow_up = np.uint8([32, 255, 255])
        cls.green_low = np.uint8([41, 100, 100])
        cls.green_up = np.uint8([67, 255, 255])
        cls.blue_low = np.uint8([111, 100, 100])
        cls.blue_up = np.uint8([121, 255, 255])
        cls.pink_low = np.uint8([166, 100, 100])
        cls.pink_up = np.uint8([173, 255, 255])
        cls.purple_low = np.uint8([141, 100, 100])
        cls.purple_up = np.uint8([160, 255, 255])

        cls.img_h = 250
        cls.img_w = 500
        cls.radius_red = 50
        cls.radius_green = 40
        cls.radius_blue = 30
        cls.radius_pink = 30
        cls.center_red = (60,60)        # x,y
        cls.center_green = (250,150)    # x,y
        cls.center_blue = (400,200)     # x,y
        cls.center_pink = (60, 200)     # x,y
        cls.area_red = int(np.pi*(cls.radius_red*cls.radius_red))
        cls.area_green = int(np.pi * (cls.radius_green * cls.radius_green))
        cls.area_blue = int(np.pi * (cls.radius_blue * cls.radius_blue))

        # make image
        cls.img = np.zeros((cls.img_h, cls.img_w, 3), np.uint8)
        cls.img[:, :] = [0, 0, 0]
        cv2.circle(cls.img, cls.center_red, cls.radius_red, (0, 0, 255), -1)
        cv2.circle(cls.img, cls.center_green, cls.radius_green, (0, 255, 0), -1)
        cv2.circle(cls.img, cls.center_blue, cls.radius_blue, (255, 0, 0), -1)
        cv2.circle(cls.img, cls.center_pink, cls.radius_pink, (180, 105, 255), -1)
        cls.hsv_img = cv2.cvtColor(cls.img, cv2.COLOR_BGR2HSV)
        # cv2.imshow('original',cls.img)
        # cv2.imshow('hsv', cls.hsv_img)
        # cv2.waitKey(0)

    # test existing color
    def test_red(self):
        red_mask = bf.getColorMask(self.red_low, self.red_up, self.hsv_img)
        if opencv_2:
            cntsR, hierarchy = cv2.findContours(red_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        else:
            img, cntsR, hierarchy = cv2.findContours(red_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        M = cv2.moments(cntsR[0])
        cX = int(M["m10"] / M["m00"])
        cY = int(M["m01"] / M["m00"])
        area = int(cv2.contourArea(cntsR[0]))

        self.assertEqual(self.center_red[0],cX, 'Red x coordinate not correct')
        self.assertEqual(self.center_red[1], cY, 'Red y coordinate not correct')
        self.assertLess(area, self.area_red, 'Red area is not correct')

    # test existing color
    def test_green(self):
        green_mask = bf.getColorMask(self.green_low, self.green_up, self.hsv_img)
        if opencv_2:
            cntsR, hierarchy = cv2.findContours(green_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        else:
            img, cntsR, hierarchy = cv2.findContours(green_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        M = cv2.moments(cntsR[0])
        cX = int(M["m10"] / M["m00"])
        cY = int(M["m01"] / M["m00"])
        area = int(cv2.contourArea(cntsR[0]))

        self.assertEqual(self.center_green[0],cX, 'Green x coordinate not correct')
        self.assertEqual(self.center_green[1], cY, 'Green y coordinate not correct')
        self.assertLess(area, self.area_green, 'Green area is not correct')

    # test existing color
    def test_blue(self):
        blue_mask = bf.getColorMask(self.blue_low, self.blue_up, self.hsv_img)
        if opencv_2:
            cntsR, hierarchy = cv2.findContours(blue_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        else:
            img, cntsR, hierarchy = cv2.findContours(blue_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        M = cv2.moments(cntsR[0])
        cX = int(M["m10"] / M["m00"])
        cY = int(M["m01"] / M["m00"])
        area = int(cv2.contourArea(cntsR[0]))

        self.assertEqual(self.center_blue[0],cX, 'Blue x coordinate not correct')
        self.assertEqual(self.center_blue[1], cY, 'Blue y coordinate not correct')
        self.assertLess(area, self.area_blue, 'Blue area is not correct')

    # test inexistent color
    def test_yellow(self):
        yellow_mask = bf.getColorMask(self.yellow_low, self.yellow_up, self.hsv_img)
        if opencv_2:
            cntsR, hierarchy = cv2.findContours(yellow_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        else:
            img, cntsR, hierarchy = cv2.findContours(yellow_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        found_yellow = len(cntsR) != 0
        self.assertFalse(found_yellow, 'Spurious yellow was found.')

    # test inexistent color
    def test_purple(self):
        purple_mask = bf.getColorMask(self.purple_low, self.purple_up, self.hsv_img)
        if opencv_2:
            cntsR, hierarchy = cv2.findContours(purple_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        else:
            img, cntsR, hierarchy = cv2.findContours(purple_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        found_purple = len(cntsR) != 0
        self.assertFalse(found_purple, 'Spurious purple was found.')


# test with real image
class testDiskDetectionTower(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tower = cv2.imread('/home/baxter/ros_ws/src/hanoi/src/test/tower_test.png')
        cls.height = cls.tower.shape[0]
        cls.width = cls.tower.shape[1]
        cls.middle = int(cls.width/2)
        cls.hsv_tower = cv2.cvtColor(cls.tower, cv2.COLOR_BGR2HSV)

        # found with colorspace analysis
        cls.pink_low = np.uint8([0, 79, 178])
        cls.pink_up = np.uint8([3, 166, 252])
        cls.red_low = np.uint8([0, 122, 0])     # not there
        cls.red_up = np.uint8([3, 255, 187])    # not there
        cls.orange_low = np.uint8([4, 137, 0])
        cls.orange_up = np.uint8([14, 255, 255])
        cls.yellow_low = np.uint8([19, 115, 0])
        cls.yellow_up = np.uint8([35, 255, 255])
        cls.green_low = np.uint8([43, 47, 0])
        cls.green_up = np.uint8([77, 255, 255])
        cls.blue_low = np.uint8([89, 71, 0])    # not there
        cls.blue_up = np.uint8([106, 255, 255]) # not there
        cls.darkblue_low = np.uint8([106, 71, 0])
        cls.darkblue_up = np.uint8([149, 255, 255])


    def test_colors_in(self):

        # pink
        pink_mask = bf.getColorMask(self.pink_low, self.pink_up, self.hsv_tower)
        if opencv_2:
            cntsR, hierarchy = cv2.findContours(pink_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        else:
            img, cntsR, hierarchy = cv2.findContours(pink_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        M = cv2.moments(cntsR[0])
        pink_found = (len(cntsR) != 0)
        pink_x = int(M["m10"] / M["m00"])
        pink_y = int(M["m01"] / M["m00"])

        # orange
        orange_mask = bf.getColorMask(self.orange_low, self.orange_up, self.hsv_tower)
        if opencv_2:
            cntsR, hierarchy = cv2.findContours(orange_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        else:
            img, cntsR, hierarchy = cv2.findContours(orange_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        M = cv2.moments(cntsR[0])
        orange_found = (len(cntsR) != 0)
        orange_x = int(M["m10"] / M["m00"])
        orange_y = int(M["m01"] / M["m00"])

        # yellow
        yellow_mask = bf.getColorMask(self.yellow_low, self.yellow_up, self.hsv_tower)
        if opencv_2:
            cntsR, hierarchy = cv2.findContours(yellow_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        else:
            img, cntsR, hierarchy = cv2.findContours(yellow_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        M = cv2.moments(cntsR[0])
        yellow_found = (len(cntsR) != 0)
        yellow_x = int(M["m10"] / M["m00"])
        yellow_y = int(M["m01"] / M["m00"])

       # green
        green_mask = bf.getColorMask(self.green_low, self.green_up, self.hsv_tower)
        if opencv_2:
            cntsR, hierarchy = cv2.findContours(green_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        else:
            img, cntsR, hierarchy = cv2.findContours(green_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        M = cv2.moments(cntsR[0])
        green_found = (len(cntsR) != 0)
        green_x = int(M["m10"] / M["m00"])
        green_y = int(M["m01"] / M["m00"])

        # darkblue
        darkblue_mask = bf.getColorMask(self.darkblue_low, self.darkblue_up, self.hsv_tower)
        if opencv_2:
            cntsR, hierarchy = cv2.findContours(darkblue_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        else:
            img, cntsR, hierarchy = cv2.findContours(darkblue_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        M = cv2.moments(cntsR[0])
        darkblue_found = (len(cntsR) != 0)
        darkblue_x = int(M["m10"] / M["m00"])
        darkblue_y = int(M["m01"] / M["m00"])

        # check if colors can be found
        self.assertTrue(pink_found, 'Pink not found on tower')
        self.assertTrue(orange_found, 'Orange not found on tower')
        self.assertTrue(yellow_found, 'Yellow not found on tower')
        self.assertTrue(green_found, 'Green not found on tower')
        self.assertTrue(darkblue_found, 'Dark blue not found on tower')

        # check blobs positions (left/right)
        self.assertLess(pink_x,self.middle,'Pink disk not detected on correct side')
        self.assertGreater(orange_x, self.middle, 'Orange disk not detected on correct side')
        self.assertGreater(yellow_x, self.middle, 'Yellow disk not detected on correct side')
        self.assertGreater(green_x, self.middle, 'Green disk not detected on correct side')
        self.assertGreater(darkblue_x, self.middle, 'Dark blue disk not detected on correct side')

        # check positions on tower
        self.assertGreater(yellow_y, orange_y, 'Yellow disk not below orange disk')
        self.assertGreater(green_y, yellow_y, 'Green disk not below yellow disk')
        self.assertGreater(darkblue_y, green_y, 'Dark blue disk not below green disk')


    def test_colors_out(self):
        # red
        red_mask = bf.getColorMask(self.red_low, self.red_up, self.hsv_tower)
        if opencv_2:
            cntsR, hierarchy = cv2.findContours(red_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        else:
            img, cntsR, hierarchy = cv2.findContours(red_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        red_found = (len(cntsR) != 0)

        # blue
        blue_mask = bf.getColorMask(self.blue_low, self.blue_up, self.hsv_tower)
        if opencv_2:
            cntsR, hierarchy = cv2.findContours(blue_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        else:
            img, cntsR, hierarchy = cv2.findContours(blue_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        blue_found = (len(cntsR) != 0)

        self.assertFalse(red_found, 'Spurious red was found.')
        self.assertFalse(blue_found, 'Spurious blue was found.')


class testMultipleColors(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # define blobs
        cls.red_low = np.uint8([0, 100, 100])
        cls.red_up = np.uint8([6, 255, 255])
        cls.green_low = np.uint8([41, 100, 100])
        cls.green_up = np.uint8([67, 255, 255])
        cls.blue_low = np.uint8([111, 100, 100])
        cls.blue_up = np.uint8([121, 255, 255])
        cls.radius_red = 50
        cls.radius_green = 40
        cls.radius_blue = 30
        cls.center_red = (60,60)        # x,y
        cls.center_green = (250,150)    # x,y
        cls.center_blue = (400,200)     # x,y
        cls.img_h = 250
        cls.img_w = 500

        # make colors masks
        cls.red_mask = np.zeros((cls.img_h, cls.img_w, 1), np.uint8)
        cv2.circle(cls.red_mask, cls.center_red, cls.radius_red, 255, -1)
        cls.green_mask = np.zeros((cls.img_h, cls.img_w, 1), np.uint8)
        cv2.circle(cls.green_mask, cls.center_green, cls.radius_green, 255, -1)
        cls.blue_mask = np.zeros((cls.img_h, cls.img_w, 1), np.uint8)
        cv2.circle(cls.blue_mask, cls.center_blue, cls.radius_blue, 255, -1)


    # test existing colors
    def test_colors_in(self):
        all_colors = ['red','green','blue']
        found_contours,found_colors = bf.getContours([self.red_mask,self.green_mask,self.blue_mask], all_colors)

        self.assertEqual(len(found_contours),len(found_colors),'Number of contours and colors found differ')
        self.assertEqual(len(found_colors),len(all_colors),'Not all colors could be found')


    def test_colors_out(self):
        all_colors = ['red','green','blue','purple']
        found_contours,found_colors = bf.getContours([self.red_mask,self.green_mask,self.blue_mask], all_colors)

        self.assertNotEqual(len(found_colors),len(all_colors),'Spurious colors found')


class testBoundingBoxes(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        # define blobs
        cls.col_dict = {
            'red': [np.uint8([0, 100, 100]), np.uint8([6, 255, 255])],
            'yellow': [np.uint8([26, 100, 100]), np.uint8([32, 255, 255])],
            'green': [np.uint8([41, 100, 100]), np.uint8([67, 255, 255])],
            'blue': [np.uint8([111, 100, 100]), np.uint8([121, 255, 255])],
            'pink': [np.uint8([166, 100, 100]), np.uint8([173, 255, 255])],
            'purple': [np.uint8([141, 100, 100]), np.uint8([160, 255, 255])]
        }

        cls.img_h = 500
        cls.img_w = 400
        cls.radius_red = 30
        cls.radius_green = 40
        cls.radius_blue = 50
        cls.radius_yellow = 60
        cls.center_red = (200,40)        # x,y
        cls.center_green = (200,120)    # x,y
        cls.center_blue = (200,210)     # x,y
        cls.center_yellow = (200, 330)     # x,y

        # make image
        cls.img = np.zeros((cls.img_h, cls.img_w, 3), np.uint8)
        cls.img[:, :] = [0, 0, 0]
        cv2.circle(cls.img, cls.center_red, cls.radius_red, (0, 0, 255), -1)
        cv2.circle(cls.img, cls.center_green, cls.radius_green, (0, 255, 0), -1)
        cv2.circle(cls.img, cls.center_blue, cls.radius_blue, (255, 0, 0), -1)
        cv2.circle(cls.img, cls.center_yellow, cls.radius_yellow, (0, 255, 255), -1)

        # add noisy blobs
        cv2.circle(cls.img, (5,5), 7, (0, 0, 255), -1)
        cv2.circle(cls.img, (380, 380), 10, (0, 0, 255), -1)
        cv2.circle(cls.img, (150,150), 10, (0, 255, 0), -1)
        cv2.circle(cls.img, (320,320), 30, (255, 0, 0), -1)
        cv2.circle(cls.img, (50,440), 20, (0, 255, 255), -1)

        # cv2.imshow('',cls.img)
        # cv2.waitKey(0)


    def test_all_colors(self):
        colors_of_interest = ['red','green','blue','yellow']
        centers_x,centers_y,widths,heights,rotations,found_colors,found_contours = bf.getBoundingBoxes (self.img, self.col_dict,colors_of_interest)

        # check if all colors are found
        self.assertEqual(len(found_colors),len(colors_of_interest),'Different number of colors found')

        # check position of disks
        self.assertGreater(centers_y[1],centers_y[0], 'Green disk not below red disk')
        self.assertGreater(centers_y[2], centers_y[1], 'Blue disk not below green disk')
        self.assertGreater(centers_y[3], centers_y[2], 'Yellow disk not below blue disk')

        # check coordinates of disks
        self.assertEqual(centers_x[0], self.center_red[0],'Red x coordinate not correct')
        self.assertEqual(centers_y[0], self.center_red[1], 'Red y coordinate not correct')
        self.assertEqual(centers_x[1], self.center_green[0],'Green x coordinate not correct')
        self.assertEqual(centers_y[1], self.center_green[1], 'Green y coordinate not correct')
        self.assertEqual(centers_x[2], self.center_blue[0],'Blue x coordinate not correct')
        self.assertEqual(centers_y[2], self.center_blue[1], 'Blue y coordinate not correct')
        self.assertEqual(centers_x[3], self.center_yellow[0],'Yellow x coordinate not correct')
        self.assertEqual(centers_y[3], self.center_yellow[1], 'Yellow y coordinate not correct')


    def test_subset_colors(self):
        colors_of_interest = ['red', 'green']
        centers_x, centers_y, widths, heights, rotations, found_colors, found_contours = bf.getBoundingBoxes(self.img, self.col_dict, colors_of_interest)

        # check if all colors are found
        self.assertEqual(len(found_colors), len(colors_of_interest), 'Different number of colors found')

        # check position of disks
        self.assertGreater(centers_y[1], centers_y[0], 'Green disk not below red disk')

        # check coordinates of disks
        self.assertEqual(centers_x[0], self.center_red[0],'Red x coordinate not correct')
        self.assertEqual(centers_y[0], self.center_red[1], 'Red y coordinate not correct')
        self.assertEqual(centers_x[1], self.center_green[0],'Green x coordinate not correct')
        self.assertEqual(centers_y[1], self.center_green[1], 'Green y coordinate not correct')


    # test with colors that are not in the image
    def test_more_colors(self):
        colors_of_interest = ['red', 'green', 'blue', 'yellow', 'pink', 'purple']
        centers_x,centers_y,widths,heights,rotations,found_colors,found_contours = bf.getBoundingBoxes (self.img, self.col_dict,colors_of_interest)

        # check what colors are found
        self.assertLess(len(found_colors),len(colors_of_interest),'Spurious colors were found (pink/purple)')





if __name__ == '__main__':
    unittest.main()

