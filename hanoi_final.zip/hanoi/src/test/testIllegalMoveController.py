#!/usr/bin/env python

PKG="hanoi"
import roslib
roslib.load_manifest(PKG)
import rospy
import unittest
import rostest
from std_msgs.msg import Int8
from std_msgs.msg import String
from hanoi.msg import Board
from hanoi.msg import FilteredBoard
from hanoi.msg import Disk





class testIllegalMoveController(unittest.TestCase):
    @classmethod
    def setUpClass(cls):

        cls.ALLOWED_WRONG_MOVES = 3
        cls.user_feedback = ''
        cls.expected_string = "Game over. Too many wrong moves."
        cls.game_running = None


        # create node
        rospy.init_node('illegalMoveControllerTEST', anonymous=True)

        # create publiher to the game state
        cls.gameRunningSub = rospy.Subscriber('/hanoi/gameRunning', Int8,cls.recievedGameRunning)

        cls.wrongMovesPub = rospy.Publisher('/hanoi/wrongMoves', Int8)

        # subscriber to which filtered (and stable) board state
        cls.userFeedbackSub = rospy.Subscriber('/hanoi/userFeedback', String, cls.receivedUserFeedback)

        rospy.sleep(2.0)


    @classmethod
    def receivedUserFeedback(self, data):
        self.user_feedback = data.data

    @classmethod
    def recievedGameRunning(self, data):
        self.game_running = data.data


    def tearDown(self):
        self.user_feedback = ''


    def test_illegal_moves(self):
        self.wrongMovesPub.publish(self.ALLOWED_WRONG_MOVES + 1)
        rospy.sleep(2.0)
        self.assertEqual(2, self.game_running, 'game running not set to 2 after allowed number of moves is exceeded')
        self.assertEqual(self.expected_string, self.user_feedback, 'feedback incorrect')


if __name__ == '__main__':
    rostest.rosrun(PKG, "test_illegal_move_controller", testIllegalMoveController)