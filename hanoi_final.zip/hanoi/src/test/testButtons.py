#!/usr/bin/env python

import rospy
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
import baxter_interface


import cv2
import numpy as np



# publisher to which we post messages for Baxter's screen
buttonPub = rospy.Publisher('/robot/xdisplay', Image)


bridge = CvBridge()


def gameRulesButtonCallback(v):
    # global bridge
    if v == True:
        print('I want game rules')
        img = np.ones((400, 600, 1), np.uint8) * 255
        cv2.putText(img, 'I want game rules', (30, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2)
        cv2.imshow('',img)
        cv2.waitKey(1)
        # img_out = bridge.cv2_to_imgmsg(img, "bgr8")
        # buttonPub.publish(img_out)


def quitButtonCallback(b):
    # global bridge
    if b == True:
        msg = 'I want to quit game'
        print(msg)
        img = np.ones((400, 600, 1), np.uint8) * 255
        cv2.putText(img, msg, (30, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2)
        cv2.imshow('', img)
        cv2.waitKey(1)
        # img_out = bridge.cv2_to_imgmsg(img, "bgr8")
        # buttonPub.publish(img_out)


def playAgainButtonCallback(n):
    # global bridge
    if n == True:
        msg = 'I want to play again'
        print(msg)
        img = np.ones((400, 600, 1), np.uint8) * 255
        cv2.putText(img, msg, (30, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2)
        cv2.imshow('', img)
        cv2.waitKey(1)
        # img_out = bridge.cv2_to_imgmsg(img, "bgr8")
        # buttonPub.publish(img_out)


def startGameButtonCallback(a):
    # global bridge
    if a == True:
        msg = 'I want to start game'
        print(msg)
        img = np.ones((400, 600, 1), np.uint8) * 255
        cv2.putText(img, msg, (30, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2)
        cv2.imshow('', img)
        cv2.waitKey(1)
        # img_out = bridge.cv2_to_imgmsg(img, "bgr8")
        # buttonPub.publish(img_out)


def hintButtonCallback(g):
    # global bridge
    if g == True:
        msg = 'I want a hint'
        print(msg)
        img = np.ones((400, 600, 1), np.uint8) * 255
        cv2.putText(img, msg, (30, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2)
        cv2.imshow('', img)
        cv2.waitKey(1)
        # img_out = bridge.cv2_to_imgmsg(img, "bgr8")
        # buttonPub.publish(img_out)


def noHintButtonCallback(t):
    # global bridge
    if t == True:
        msg = 'I don\'t want a hint'
        print(msg)
        img = np.ones((400, 600, 1), np.uint8) * 255
        cv2.putText(img, msg, (30, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2)
        cv2.imshow('', img)
        cv2.waitKey(1)
        # img_out = bridge.cv2_to_imgmsg(img, "bgr8")
        # buttonPub.publish(img_out)


def boardRearrangedButtonCallback(o):
    # global bridge
    if o == True:
        msg = 'Rearrange board button'
        print(msg)
        img = np.ones((400, 600, 1), np.uint8) * 255
        cv2.putText(img, msg, (30, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2)
        cv2.imshow('', img)
        cv2.waitKey(1)
        # img_out = bridge.cv2_to_imgmsg(img, "bgr8")
        # buttonPub.publish(img_out)




if __name__ == "__main__":

    # create node
    rospy.init_node('testButtons', anonymous=True)

    # create subscriber to the right arm button
    rightArmNav = baxter_interface.Navigator('right')

    # check for left arm button 0 press for game rules explanation
    rightArmNav.button0_changed.connect(gameRulesButtonCallback)

    # check for left arm button 1 press for quit game
    rightArmNav.button1_changed.connect(quitButtonCallback)

    # check for left arm button 2 press for play again
    rightArmNav.button2_changed.connect(playAgainButtonCallback)

    # create subscriber to the right arm button
    leftArmNav = baxter_interface.Navigator('left')

    # check for left arm button 0 press for start game
    leftArmNav.button0_changed.connect(startGameButtonCallback)

    # check for left arm button 1 press for I want a hint
    leftArmNav.button1_changed.connect(hintButtonCallback)

    # check for left arm button 2 press for no hint
    leftArmNav.button2_changed.connect(noHintButtonCallback)

    # create subscriber to the left arm button
    rightTorsoNav = baxter_interface.Navigator('torso_right')

    # check for right torso button 2 press for BOARD HAS BEEN REARRANGED
    rightTorsoNav.button2_changed.connect(boardRearrangedButtonCallback)

    # prevents program from exiting, allowing subscribers and publishers to keep operating
    rospy.spin()