#!/usr/bin/env python

PKG="hanoi"
import roslib
roslib.load_manifest(PKG)
import rospy
import unittest
import rostest
from std_msgs.msg import Int8
from hanoi.msg import Board
from hanoi.msg import FilteredBoard
from hanoi.msg import Disk


# initializations
string_col = rospy.get_param("/hanoi_colors")
hanoi_colors = string_col.split(',')
MAX_WINDOW_SIZE = rospy.get_param("/MAX_WINDOW_SIZE")
MIN_NUM_VOTES = rospy.get_param("/MIN_NUM_VOTES")
PUBLISH_DELAY = rospy.get_param("/PUBLISH_DELAY")


class testBoardChangeController(unittest.TestCase):
    @classmethod
    def setUpClass(cls):

        # make disks to be used by test cases
        cls.disk_pink = Disk('pink', 1)
        cls.disk_red = Disk('red', 2)
        cls.disk_orange = Disk('orange', 3)
        cls.disk_yellow = Disk('yellow', 4)
        cls.disk_green = Disk('green', 5)
        cls.disk_dark_green = Disk('dark_green', 6)
        cls.disk_blue = Disk('blue', 7)
        cls.disk_dark_blue = Disk('dark_blue', 8)

        cls.filtered_board = None

        # create node
        rospy.init_node('boardChangeControllerTEST', anonymous=True)

        # create publiher to the game state
        cls.gameRunningPub = rospy.Publisher('/hanoi/gameRunning', Int8)

        # create publisher to the board state topic
        cls.boardStatePub = rospy.Publisher('/hanoi/boardState', Board)

        # subscriber to which filtered (and stable) board state
        cls.filteredboardSub = rospy.Subscriber('/hanoi/filteredBoardState', FilteredBoard,
                                                cls.receivedFilteredBoard)


    @classmethod
    def receivedFilteredBoard(self, data):
        self.filtered_board = data


    def tearDown(self):
        self.filtered_board = None


    # test with 2 spurious board configs
    def test_board_state_config1(self):

        # Board 1:
        # left tower: orange, red, pink
        # middle tower: yellow, green
        # right tower: dark_blue, blue, dark_green
        board_msg_1 = Board()
        board_msg_1.left.append(self.disk_orange)
        board_msg_1.left.append(self.disk_red)
        board_msg_1.left.append(self.disk_pink)
        board_msg_1.middle.append(self.disk_yellow)
        board_msg_1.middle.append(self.disk_green)
        board_msg_1.right.append(self.disk_dark_blue)
        board_msg_1.right.append(self.disk_blue)
        board_msg_1.right.append(self.disk_dark_green)

        # Board 2:
        # left tower: orange, red
        # middle tower: yellow, green
        # right tower: dark_blue, blue, dark_green, pink
        board_msg_2 = Board()
        board_msg_2.left.append(self.disk_orange)
        board_msg_2.left.append(self.disk_red)
        board_msg_2.middle.append(self.disk_yellow)
        board_msg_2.middle.append(self.disk_green)
        board_msg_2.right.append(self.disk_dark_blue)
        board_msg_2.right.append(self.disk_blue)
        board_msg_2.right.append(self.disk_dark_green)
        board_msg_2.right.append(self.disk_pink)

        # start game
        rospy.sleep(2.0)
        self.gameRunningPub.publish(1)
        rospy.sleep(2.0)  # sleep for 2 seconds

        # publish Board 1 to board many times
        for i in range(MAX_WINDOW_SIZE-2):
            self.boardStatePub.publish(board_msg_1)
            rospy.sleep(0.1)
        # publish Board 2 to board few times
        for i in range(2):
            self.boardStatePub.publish(board_msg_2)
            rospy.sleep(0.1)
        # publish Board 1 to board many times
        for i in range(int(MAX_WINDOW_SIZE/2)):
            self.boardStatePub.publish(board_msg_1)
            rospy.sleep(0.1)
        rospy.sleep(10.0)   # sleep for 10 seconds to wait for messages to be processed by tested node

        # the received filtered board should be Board 1
        self.assertEqual(self.filtered_board.left[0].disk_color,'orange')
        self.assertEqual(self.filtered_board.left[1].disk_color, 'red')
        self.assertEqual(self.filtered_board.left[2].disk_color, 'pink')
        self.assertEqual(self.filtered_board.middle[0].disk_color, 'yellow')
        self.assertEqual(self.filtered_board.middle[1].disk_color, 'green')
        self.assertEqual(self.filtered_board.right[0].disk_color, 'dark_blue')
        self.assertEqual(self.filtered_board.right[1].disk_color, 'blue')


    # test with a valid board change
    def test_board_state_config2(self):

        # Board 1:
        # left tower: orange, red, pink
        # middle tower: yellow, green
        # right tower: dark_blue, blue, dark_green
        board_msg_1 = Board()
        board_msg_1.left.append(self.disk_orange)
        board_msg_1.left.append(self.disk_red)
        board_msg_1.left.append(self.disk_pink)
        board_msg_1.middle.append(self.disk_yellow)
        board_msg_1.middle.append(self.disk_green)
        board_msg_1.right.append(self.disk_dark_blue)
        board_msg_1.right.append(self.disk_blue)
        board_msg_1.right.append(self.disk_dark_green)

        # Board 2:
        # left tower: orange, red
        # middle tower: yellow, green, pink
        # right tower: dark_blue, blue, dark_green
        board_msg_2 = Board()
        board_msg_2.left.append(self.disk_orange)
        board_msg_2.left.append(self.disk_red)
        board_msg_2.middle.append(self.disk_yellow)
        board_msg_2.middle.append(self.disk_green)
        board_msg_2.middle.append(self.disk_pink)
        board_msg_2.right.append(self.disk_dark_blue)
        board_msg_2.right.append(self.disk_blue)
        board_msg_2.right.append(self.disk_dark_green)

        # start game
        rospy.sleep(2.0)
        self.gameRunningPub.publish(1)
        rospy.sleep(2.0)  # sleep for 2 seconds

        # publish Board 1 to topic many times
        for i in range(MAX_WINDOW_SIZE-2):
            self.boardStatePub.publish(board_msg_1)
            rospy.sleep(0.1)
        # publish Board 2 to topic many times
        for i in range(MAX_WINDOW_SIZE):
            self.boardStatePub.publish(board_msg_2)
            rospy.sleep(0.1)
        rospy.sleep(10.0)   # sleep for 10 seconds to wait for messages to be processed by tested node

        # the received filtered board should be Board 2
        self.assertEqual(self.filtered_board.left[0].disk_color,'orange')
        self.assertEqual(self.filtered_board.left[1].disk_color, 'red')
        self.assertEqual(self.filtered_board.middle[0].disk_color, 'yellow')
        self.assertEqual(self.filtered_board.middle[1].disk_color, 'green')
        self.assertEqual(self.filtered_board.middle[2].disk_color, 'pink')
        self.assertEqual(self.filtered_board.right[0].disk_color, 'dark_blue')
        self.assertEqual(self.filtered_board.right[1].disk_color, 'blue')


    # test with a missing disk
    def test_board_state_config3(self):

        # Board 1:
        # left tower: orange, red, pink
        # middle tower: yellow, green
        # right tower: dark_blue, blue, dark_green
        board_msg_1 = Board()
        board_msg_1.left.append(self.disk_orange)
        board_msg_1.left.append(self.disk_red)
        board_msg_1.left.append(self.disk_pink)
        board_msg_1.middle.append(self.disk_yellow)
        board_msg_1.middle.append(self.disk_green)
        board_msg_1.right.append(self.disk_dark_blue)
        board_msg_1.right.append(self.disk_blue)
        board_msg_1.right.append(self.disk_dark_green)

        # Board 2:
        # left tower: orange, red
        # middle tower: yellow, green
        # right tower: dark_blue, blue, dark_green
        board_msg_2 = Board()
        board_msg_2.left.append(self.disk_orange)
        board_msg_2.left.append(self.disk_red)
        board_msg_2.middle.append(self.disk_yellow)
        board_msg_2.middle.append(self.disk_green)
        board_msg_2.right.append(self.disk_dark_blue)
        board_msg_2.right.append(self.disk_blue)
        board_msg_2.right.append(self.disk_dark_green)

        # start game
        rospy.sleep(2.0)
        self.gameRunningPub.publish(1)
        rospy.sleep(2.0)  # sleep for 2 seconds

        # publish Board 1 to topic many times
        for i in range(int(MAX_WINDOW_SIZE/2)):
            self.boardStatePub.publish(board_msg_1)
            rospy.sleep(0.1)
        # publish Board 2 to topic few times
        for i in range(2):
            self.boardStatePub.publish(board_msg_2)
            rospy.sleep(0.1)
        # publish Board 1 to topic many times
        for i in range(int(MAX_WINDOW_SIZE/2)):
            self.boardStatePub.publish(board_msg_1)
            rospy.sleep(0.1)
        rospy.sleep(10.0)   # sleep for 10 seconds to wait for messages to be processed by tested node

        # the received filtered board should be Board 1
        self.assertEqual(self.filtered_board.left[0].disk_color,'orange')
        self.assertEqual(self.filtered_board.left[1].disk_color, 'red')
        self.assertEqual(self.filtered_board.left[2].disk_color, 'pink')
        self.assertEqual(self.filtered_board.middle[0].disk_color, 'yellow')
        self.assertEqual(self.filtered_board.middle[1].disk_color, 'green')
        self.assertEqual(self.filtered_board.right[0].disk_color, 'dark_blue')
        self.assertEqual(self.filtered_board.right[1].disk_color, 'blue')


if __name__ == '__main__':
    rostest.rosrun(PKG, "test_board_change_controller", testBoardChangeController)