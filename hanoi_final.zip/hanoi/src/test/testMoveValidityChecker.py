#!/usr/bin/env python

PKG="hanoi"
import roslib
roslib.load_manifest(PKG)
import rospy
import unittest
import rostest
from std_msgs.msg import Int8
from hanoi.msg import FilteredBoard
from hanoi.msg import Disk


# initializations
string_col = rospy.get_param("/hanoi_colors")
hanoi_colors = string_col.split(',')


class testMoveValidityChecker(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # make disks to be used by test cases
        cls.disk_pink = Disk('pink', 1)
        cls.disk_red = Disk('red', 2)
        cls.disk_orange = Disk('orange', 3)
        cls.disk_yellow = Disk('yellow', 4)
        cls.disk_green = Disk('green', 5)
        cls.disk_dark_green = Disk('dark_green', 6)
        cls.disk_blue = Disk('blue', 7)
        cls.disk_dark_blue = Disk('dark_blue', 8)

        # class related variables
        cls.last_valid_board = None
        cls.move_code = []

        # create node
        rospy.init_node('moveValidityCheckerTEST', anonymous=True)

        # subscriber to last valid board
        cls.lastValidBoardSub = rospy.Subscriber('/hanoi/lastValidBoard', FilteredBoard, cls.callbackLastValid)

        # create publisher to the filtered board topic
        cls.filteredBoardPub = rospy.Publisher('/hanoi/filteredBoardState', FilteredBoard)

        # # create publisher to the missing disk topic
        # cls.missingDiskPub = rospy.Publisher('/hanoi/missingDisk', Bool)

        # subscriber for move validity code
        cls.validMoveSub = rospy.Subscriber('/hanoi/validMove', Int8, cls.callbackMoveCode)

        # need to sleep to allow this node to subscribe
        rospy.sleep(2.0)

        # set an initial board
        # left tower: orange, red, pink
        # middle tower: green, yellow
        # right tower: dark_blue, blue, dark_green
        # encoding: [2,2,2,1,1,0,0,0]
        board_initial = FilteredBoard()
        board_initial.left.append(cls.disk_orange)
        board_initial.left.append(cls.disk_red)
        board_initial.left.append(cls.disk_pink)
        board_initial.middle.append(cls.disk_green)
        board_initial.middle.append(cls.disk_yellow)
        board_initial.right.append(cls.disk_dark_blue)
        board_initial.right.append(cls.disk_blue)
        board_initial.right.append(cls.disk_dark_green)
        board_initial.encoded = [2,2,2,1,1,0,0,0]
        cls.board_initial = board_initial

        # publish initial board to topic and wait
        cls.filteredBoardPub.publish(cls.board_initial)
        rospy.sleep(2.0)


    @classmethod
    def callbackMoveCode(self, data):
        self.move_code.append(data.data)

    @classmethod
    def callbackLastValid(self, data):
        self.last_valid_board = data


    @classmethod
    def setUp(self):
        self.move_code = []


    def compare(self,a,b):
        # differing lenghts
        if len(a) != len(b):
            return False
        # equal lengths
        for i in range(len(a)):
            if a[i] != b[i]:
                return False
        return True


    # publish a new valid board to filtered board topic
    # move should be seen as correct and the filtered board updated
    def test_1(self):

        # move pink disk to middle tower
        # left tower: orange, red
        # middle tower: green, yellow, pink
        # right tower: dark_blue, blue, dark_green
        # encoding: [2,2,2,1,1,0,0,1]
        board_new = FilteredBoard()
        board_new.left.append(self.disk_orange)
        board_new.left.append(self.disk_red)
        board_new.middle.append(self.disk_green)
        board_new.middle.append(self.disk_yellow)
        board_new.middle.append(self.disk_pink)
        board_new.right.append(self.disk_dark_blue)
        board_new.right.append(self.disk_blue)
        board_new.right.append(self.disk_dark_green)
        board_new.encoded = [2,2,2,1,1,0,0,1]

        # publish new filtered board to topic and wait
        self.filteredBoardPub.publish(board_new)
        rospy.sleep(2.0)

        # check if node is publishing correct move code (1)
        self.assertEqual(self.move_code[0],1)

        # check if last valid board is updated to Board 2
        self.assertEqual(self.last_valid_board.left[0].disk_color,'orange')
        self.assertEqual(self.last_valid_board.left[1].disk_color, 'red')
        self.assertEqual(self.last_valid_board.middle[0].disk_color, 'green')
        self.assertEqual(self.last_valid_board.middle[1].disk_color, 'yellow')
        self.assertEqual(self.last_valid_board.middle[2].disk_color, 'pink')
        self.assertEqual(self.last_valid_board.right[0].disk_color, 'dark_blue')
        self.assertEqual(self.last_valid_board.right[1].disk_color, 'blue')
        self.assertEqual(self.last_valid_board.right[2].disk_color, 'dark_green')
        # check encoding as well
        self.assertTrue(self.compare(self.last_valid_board.encoded,board_new.encoded),'New valid board does not match')


    # publish a new board with missing disk to filtered board topic
    # move should be seen as "missing"
    def test_2(self):

        # remove red disk
        # left tower: orange
        # middle tower: green, yellow, pink
        # right tower: dark_blue, blue, dark_green
        # encoding: [2,2,2,1,1,0,1]
        board_new = FilteredBoard()
        board_new.left.append(self.disk_orange)
        board_new.middle.append(self.disk_green)
        board_new.middle.append(self.disk_yellow)
        board_new.middle.append(self.disk_pink)
        board_new.right.append(self.disk_dark_blue)
        board_new.right.append(self.disk_blue)
        board_new.right.append(self.disk_dark_green)
        board_new.encoded = [2,2,2,1,1,0,1]

        # publish new filtered board to topic and wait
        self.filteredBoardPub.publish(board_new)
        rospy.sleep(2.0)

        # check if node is publishing missing disk code (2)
        self.assertEqual(self.move_code[0],2)

        # check if last valid board is the previous board
        # board is not updated because node is waiting for the disk to be put back
        # left tower: orange, red
        # middle tower: green, yellow, pink
        # right tower: dark_blue, blue, dark_green
        # encoding: [2,2,2,1,1,0,0,1]
        self.assertEqual(self.last_valid_board.left[0].disk_color,'orange')
        self.assertEqual(self.last_valid_board.left[1].disk_color, 'red')
        self.assertEqual(self.last_valid_board.middle[0].disk_color, 'green')
        self.assertEqual(self.last_valid_board.middle[1].disk_color, 'yellow')
        self.assertEqual(self.last_valid_board.middle[2].disk_color, 'pink')
        self.assertEqual(self.last_valid_board.right[0].disk_color, 'dark_blue')
        self.assertEqual(self.last_valid_board.right[1].disk_color, 'blue')
        self.assertEqual(self.last_valid_board.right[2].disk_color, 'dark_green')
        # check encoding as well
        self.assertTrue(self.compare(self.last_valid_board.encoded,[2,2,2,1,1,0,0,1]),'Last valid board state shouldnt have been updated')


    # bring back the red disk in a valid position
    # this models the scenario when a disk is added from one tower to another
    def test_3(self):

        # bring back red disk (on right tower)
        # left tower: orange
        # middle tower: green, yellow, pink
        # right tower: dark_blue, blue, dark_green, red
        # encoding: [2,2,2,1,1,0,2,1]
        board_new = FilteredBoard()
        board_new.left.append(self.disk_orange)
        board_new.middle.append(self.disk_green)
        board_new.middle.append(self.disk_yellow)
        board_new.middle.append(self.disk_pink)
        board_new.right.append(self.disk_dark_blue)
        board_new.right.append(self.disk_blue)
        board_new.right.append(self.disk_dark_green)
        board_new.right.append(self.disk_red)
        board_new.encoded = [2,2,2,1,1,0,2,1]

        # publish new filtered board to topic and wait
        self.filteredBoardPub.publish(board_new)
        rospy.sleep(2.0)

        # check if node is publishing that board is valid
        self.assertEqual(self.move_code[0],1)

        # check if last valid board is updated
        self.assertEqual(self.last_valid_board.left[0].disk_color,'orange')
        self.assertEqual(self.last_valid_board.middle[0].disk_color, 'green')
        self.assertEqual(self.last_valid_board.middle[1].disk_color, 'yellow')
        self.assertEqual(self.last_valid_board.middle[2].disk_color, 'pink')
        self.assertEqual(self.last_valid_board.right[0].disk_color, 'dark_blue')
        self.assertEqual(self.last_valid_board.right[1].disk_color, 'blue')
        self.assertEqual(self.last_valid_board.right[2].disk_color, 'dark_green')
        self.assertEqual(self.last_valid_board.right[3].disk_color, 'red')
        # check encoding as well
        self.assertTrue(self.compare(self.last_valid_board.encoded,board_new.encoded),'Last valid board state not updated after disk was added')


    # publish a new board with invalid configuration
    # move should be seen as "wrong" and the filtered board should NOT be updated
    def test_4(self):

        # red disk added to invalid position (middle tower)
        # left tower: orange
        # middle tower: green, yellow, pink, red
        # right tower: dark_blue, blue, dark_green
        # encoding: [2,2,2,1,1,0,1,1]
        board_new = FilteredBoard()
        board_new.left.append(self.disk_orange)
        board_new.middle.append(self.disk_green)
        board_new.middle.append(self.disk_yellow)
        board_new.middle.append(self.disk_pink)
        board_new.middle.append(self.disk_red)
        board_new.right.append(self.disk_dark_blue)
        board_new.right.append(self.disk_blue)
        board_new.right.append(self.disk_dark_green)
        board_new.encoded = [2,2,2,1,1,0,1,1]

        # publish new filtered board to topic and wait
        self.filteredBoardPub.publish(board_new)
        rospy.sleep(2.0)

        # check if node is publishing that move is wrong (3)
        self.assertEqual(self.move_code[0],3)
        rospy.sleep(2.0)

        # check if last valid board is previous valid board before wrong move
        # left tower: orange
        # middle tower: green, yellow, pink
        # right tower: dark_blue, blue, dark_green, red
        # encoding: [2,2,2,1,1,0,2,1]
        self.assertEqual(self.last_valid_board.left[0].disk_color,'orange')
        self.assertEqual(self.last_valid_board.middle[0].disk_color, 'green')
        self.assertEqual(self.last_valid_board.middle[1].disk_color, 'yellow')
        self.assertEqual(self.last_valid_board.middle[2].disk_color, 'pink')
        self.assertEqual(self.last_valid_board.right[0].disk_color, 'dark_blue')
        self.assertEqual(self.last_valid_board.right[1].disk_color, 'blue')
        self.assertEqual(self.last_valid_board.right[2].disk_color, 'dark_green')
        self.assertEqual(self.last_valid_board.right[3].disk_color, 'red')

        # check encoding as well
        self.assertTrue(self.compare(self.last_valid_board.encoded,[2,2,2,1,1,0,2,1]),'Last valid board updated with invalid move')





if __name__ == '__main__':
    rostest.rosrun(PKG, "test_move_validity_checker", testMoveValidityChecker)