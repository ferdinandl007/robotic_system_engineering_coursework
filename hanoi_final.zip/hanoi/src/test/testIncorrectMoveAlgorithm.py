#!/usr/bin/env python

import rospy
import rostest
import unittest
from std_msgs.msg import String
from std_msgs.msg import Int8
PKG="hanoi"

# initialization
X_SECS = rospy.get_param("/X_SECS")

class testIncorrectMoveAlgorithm(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # class variables
        cls.feedback_string = None
        cls.wrong_moves = None
        cls.game_running = None

        # create node
        rospy.init_node('incorrectMoveAlgorithmTEST', anonymous=True)

        # create publisher to the valid move topic
        cls.validMovePub = rospy.Publisher('/hanoi/validMove', Int8)

        # will subscribe to the number wrong moves
        cls.wrongMovesSub = rospy.Subscriber('/hanoi/wrongMoves', Int8, cls.callbackWrongMoves)

        # will subscribe to the game state
        cls.gameRunningSub = rospy.Subscriber('/hanoi/gameRunning',Int8, cls.callbackGameRunning)

        # will subscribe to the feedback topic
        cls.feedbackSub = rospy.Subscriber('/hanoi/userFeedback',String, cls.callbackFeedback)

        # need to sleep to allow this node to subscribe
        rospy.sleep(2.0)



    @classmethod
    def callbackFeedback(self,data):
        self.feedback_string = data.data
        print("fdb:", self.feedback_string)


    @classmethod
    def callbackWrongMoves(self,data):
        self.wrong_moves = data.data


    @classmethod
    def callbackGameRunning(self,data):
        self.game_running = data.data

    def test_1(self):

        # tell the node that a wrong move has been detected and wait
        self.validMovePub.publish(3)
        rospy.sleep(1.0)

        # check if feedback has been given to the player
        self.assertTrue("wrong" in str.lower(self.feedback_string), 'No feedback on wrong move has been given to the player')

        rospy.sleep(6.0)
        # check if the number of wrong moves increased
        self.assertEqual(self.wrong_moves, 1, 'Incorrect move detected but number of wrong moves not updated')

        # wait for user to allow correction
        rospy.sleep(float(X_SECS)+3.0)    # seconds in actual node + some epsilon

        # don't publish any move: player did not correct the move

        # check if game running state has been set to 3
        self.assertEqual(self.game_running, 3, 'Game running not set to 3 (requiring setup) although incorrect move was not corrected')


if __name__ == '__main__':
    rostest.rosrun(PKG, "test_incorrect_move_algorithm", testIncorrectMoveAlgorithm)



