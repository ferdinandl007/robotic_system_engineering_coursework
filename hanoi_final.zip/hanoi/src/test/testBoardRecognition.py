import sys
sys.path.insert(0,"../")
# insert the parent folder into the path of this test
import unittest
import numpy as np
import cv2
import Queue as Queue
import copy
from collections import OrderedDict
import blobFunctions as bf
import Board as bd
import DiskNew as dk
opencv_2 = cv2.__version__.startswith('2')


# http://skchandra.github.io/neato_street_view/blog/2015/12/18/testing-workflows.html
# https://www.youtube.com/watch?v=j7-_flWgJ88
# https://www.youtube.com/watch?v=XEvAoRmdv_Q
# https://www.youtube.com/watch?v=Njm7MVJD6IE

# test with composed image
class testBoardComposed(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        # define blobs
        cls.col_dict = {
            'red': [np.uint8([0, 100, 100]), np.uint8([6, 255, 255])],
            'yellow': [np.uint8([26, 100, 100]), np.uint8([32, 255, 255])],
            'green': [np.uint8([41, 100, 100]), np.uint8([67, 255, 255])],
            'blue': [np.uint8([111, 100, 100]), np.uint8([121, 255, 255])],
            'pink': [np.uint8([166, 100, 100]), np.uint8([173, 255, 255])],
            'purple': [np.uint8([141, 100, 100]), np.uint8([160, 255, 255])]
        }
        # info used by all tests of the class
        cls.img_h = 400
        cls.img_w = 600
        cls.img_1_3 = int(cls.img_w / 3)    # one third
        cls.img_2_3 = int(2*cls.img_1_3)   # two thirds
        cls.radius_red = 30
        cls.radius_green = 40
        cls.radius_blue = 50
        cls.radius_yellow = 60


    def test_all_colors_config1(self):

        # configuration used only by this test
        center_red = (self.img_1_3 - 100, 200)          # x,y (left tower)
        center_yellow = (self.img_1_3 - 100, 300)       # x,y (left tower)
        center_blue = (self.img_2_3 - 100, 300)         # x,y (middle tower)
        center_green = (self.img_w - 100, 300)          # x,y (right tower)

        # make image
        img = np.zeros((self.img_h, self.img_w, 3), np.uint8)
        img[:, :] = [0, 0, 0]
        cv2.circle(img, center_red, self.radius_red, (0, 0, 255), -1)
        cv2.circle(img, center_green, self.radius_green, (0, 255, 0), -1)
        cv2.circle(img, center_blue, self.radius_blue, (255, 0, 0), -1)
        cv2.circle(img, center_yellow, self.radius_yellow, (0, 255, 255), -1)

        # add noisy blobs
        cv2.circle(img, (5,5), 7, (0, 0, 255), -1)
        cv2.circle(img, (400, 100), 10, (0, 0, 255), -1)
        cv2.circle(img, (150,150), 10, (0, 255, 0), -1)
        cv2.circle(img, (450,150), 15, (255, 0, 0), -1)
        cv2.circle(img, (50,440), 20, (0, 255, 255), -1)

        # cv2.imshow('',img)
        # cv2.waitKey(0)

        # ground truth
        truth = OrderedDict()  # left, middle, right
        truth['left'] = ['yellow', 'red']
        truth['middle'] = ['blue']
        truth['right'] = ['green']

        # detect
        colors_of_interest = ['red', 'green', 'blue', 'yellow']
        hanoi_board = bd.Board()
        centers_x, centers_y, widths, heights, rotations, found_colors, found_contours = bf.getBoundingBoxes(img,
                                                                                                             self.col_dict,
                                                                                                             colors_of_interest)
        # make disks from colors
        all_disks = []
        for ind,found in enumerate(found_colors):
            all_disks.append(dk.DiskNew(centers_x[ind], centers_y[ind], found, ind+1))
        hanoi_board.determineBoardLayout(False, all_disks)

        # test if all disks were found
        self.assertEqual(len(found_colors),len(colors_of_interest), 'Not all disks could be found')

        # test left tower membership
        for ind,disk in enumerate(truth['left']):
            self.assertEqual(disk,hanoi_board.left_tower[ind].color,'Error detecting '+disk+' disk on left tower')

        # test middle tower membership
        for ind,disk in enumerate(truth['middle']):
            self.assertEqual(disk,hanoi_board.middle_tower[ind].color,'Error detecting '+disk+' disk on middle tower')

        # test right tower membership
        for ind,disk in enumerate(truth['right']):
            self.assertEqual(disk,hanoi_board.right_tower[ind].color,'Error detecting '+disk+' disk on right tower')


    def test_all_colors_config2(self):

        # configuration used only by this test
        center_red = (self.img_1_3 - 100, 200)          # x,y (left tower)
        center_yellow = (self.img_1_3 - 100, 300)       # x,y (left tower)
        center_blue = (self.img_w - 100, 300)         # x,y (right tower)
        center_green = (self.img_w - 100, 200)          # x,y (right tower)

        # make image
        img = np.zeros((self.img_h, self.img_w, 3), np.uint8)
        img[:, :] = [0, 0, 0]
        cv2.circle(img, center_red, self.radius_red, (0, 0, 255), -1)
        cv2.circle(img, center_green, self.radius_green, (0, 255, 0), -1)
        cv2.circle(img, center_blue, self.radius_blue, (255, 0, 0), -1)
        cv2.circle(img, center_yellow, self.radius_yellow, (0, 255, 255), -1)

        # add noisy blobs
        cv2.circle(img, (5,5), 7, (0, 0, 255), -1)
        cv2.circle(img, (400, 100), 10, (0, 0, 255), -1)
        cv2.circle(img, (150,150), 10, (0, 255, 0), -1)
        cv2.circle(img, (450,150), 15, (255, 0, 0), -1)
        cv2.circle(img, (50,440), 20, (0, 255, 255), -1)

        # ground truth
        truth = OrderedDict()  # left, middle, right
        truth['left'] = ['yellow', 'red']
        truth['middle'] = []
        truth['right'] = ['blue','green']

        # cv2.imshow('',img)
        # cv2.waitKey(0)

        colors_of_interest = ['red', 'green', 'blue', 'yellow']
        hanoi_board = bd.Board()
        centers_x, centers_y, widths, heights, rotations, found_colors, found_contours = bf.getBoundingBoxes(img,
                                                                                                             self.col_dict,
                                                                                                             colors_of_interest)
        # make disks from colors
        all_disks = []
        for ind,found in enumerate(found_colors):
            all_disks.append(dk.DiskNew(centers_x[ind], centers_y[ind], found, ind+1))
        hanoi_board.determineBoardLayout(False, all_disks)

        # test if all disks were found
        self.assertEqual(len(found_colors),len(colors_of_interest), 'Not all disks could be found')
        # test if all disks are in board class
        nr_disks = len(hanoi_board.left_tower) + len(hanoi_board.middle_tower) + len(hanoi_board.right_tower)
        self.assertEqual(nr_disks,len(colors_of_interest),'Not all disks present on board')

        # test left tower membership
        for ind,disk in enumerate(truth['left']):
            self.assertEqual(disk,hanoi_board.left_tower[ind].color,'Error detecting '+disk+' disk on left tower')

        # test middle tower membership
        for ind,disk in enumerate(truth['middle']):
            self.assertEqual(disk,hanoi_board.middle_tower[ind].color,'Error detecting '+disk+' disk on middle tower')

        # test right tower membership
        for ind,disk in enumerate(truth['right']):
            self.assertEqual(disk,hanoi_board.right_tower[ind].color,'Error detecting '+disk+' disk on right tower')


    def test_subset_colors(self):

        # configuration used only by this test
        center_yellow = (self.img_1_3 - 100, 300)       # x,y (left tower)
        center_green = (self.img_w - 100, 300)          # x,y (right tower)

        # make image
        img = np.zeros((self.img_h, self.img_w, 3), np.uint8)
        img[:, :] = [0, 0, 0]
        cv2.circle(img, center_green, self.radius_green, (0, 255, 0), -1)
        cv2.circle(img, center_yellow, self.radius_yellow, (0, 255, 255), -1)

        # add noisy blobs
        cv2.circle(img, (5,5), 7, (0, 0, 255), -1)
        cv2.circle(img, (400, 100), 10, (0, 0, 255), -1)
        cv2.circle(img, (150,150), 10, (0, 255, 0), -1)
        cv2.circle(img, (450,150), 15, (255, 0, 0), -1)
        cv2.circle(img, (50,440), 20, (0, 255, 255), -1)

        # ground truth
        truth = OrderedDict()  # left, middle, right
        truth['left'] = ['yellow']
        truth['middle'] = []
        truth['right'] = ['green']

        # cv2.imshow('',img)
        # cv2.waitKey(0)

        colors_of_interest = ['green','yellow']
        hanoi_board = bd.Board()
        centers_x, centers_y, widths, heights, rotations, found_colors, found_contours = bf.getBoundingBoxes(img,
                                                                                                             self.col_dict,
                                                                                                             colors_of_interest)
        # make disks from colors
        all_disks = []
        for ind,found in enumerate(found_colors):
            all_disks.append(dk.DiskNew(centers_x[ind], centers_y[ind], found, ind+1))
        hanoi_board.determineBoardLayout(False, all_disks)

        # test if all disks were found
        self.assertEqual(len(found_colors),len(colors_of_interest), 'A different number of disks was found')

        # test if all disks are in board class
        nr_disks = len(hanoi_board.left_tower) + len(hanoi_board.middle_tower) + len(hanoi_board.right_tower)
        self.assertEqual(nr_disks,len(colors_of_interest),'A different number of disks present on board')

        # test left tower membership
        for ind,disk in enumerate(truth['left']):
            self.assertEqual(disk,hanoi_board.left_tower[ind].color,'Error detecting '+disk+' disk on left tower')

        # test middle tower membership
        for ind,disk in enumerate(truth['middle']):
            self.assertEqual(disk,hanoi_board.middle_tower[ind].color,'Error detecting '+disk+' disk on middle tower')

        # test right tower membership
        for ind,disk in enumerate(truth['right']):
            self.assertEqual(disk,hanoi_board.right_tower[ind].color,'Error detecting '+disk+' disk on right tower')



# test with composed image from average values after calibration
class testBoardCalibrated(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # load HSV values found during calibration
        cls.path_HSV_test = '/home/baxter/ros_ws/src/hanoi/src/test/hsv.txt'
        cls.hsv_baxter = bf.loadHSV(cls.path_HSV_test)

        # load BGR values
        cls.path_BGR_test = '/home/baxter/ros_ws/src/hanoi/src/test/bgr.txt'
        cls.bgr_baxter = bf.loadBGR(cls.path_BGR_test)

        # get color names
        cls.colors_baxter = cls.bgr_baxter.keys()

        # set sizes
        cls.img_h = 400
        cls.img_w = 600
        cls.segm = int(600/4)
        cls.radii = []
        for c in range(len(cls.colors_baxter)):
            cls.radii.append(int(30 + c*5))


    def test_all_colors_config1(self):

        coordinates = []
        height_left = self.img_h
        height_middle = self.img_h
        height_right = self.img_h

        disks_to_add = copy.deepcopy(self.colors_baxter)
        radii = copy.deepcopy(self.radii)

        # give disks a position (take disks in LIFO order - largest first)
        while len(disks_to_add) > 0:

            # put on left tower
            disk_add_left = disks_to_add.pop()
            curr_radius = radii.pop()
            coordinates.append((self.segm, height_left - curr_radius))
            height_left -= curr_radius*2

            # put of middle tower
            if len(disks_to_add) > 0:
                disk_add_middle = disks_to_add.pop()
                curr_radius = radii.pop()
                coordinates.append((self.segm * 2, height_middle - curr_radius))
                height_middle -= curr_radius * 2

            # put of right tower
            if len(disks_to_add) > 0:
                disk_add_middle = disks_to_add.pop()
                curr_radius = radii.pop()
                coordinates.append((self.segm * 3, height_right - curr_radius))
                height_right -= curr_radius * 2

        # draw disks
        img = np.zeros((self.img_h, self.img_w, 3), np.uint8)
        img[:, :] = [0, 0, 0]
        colors_reversed = self.colors_baxter[::-1]
        radii_reversed = self.radii[::-1]
        for c in range(len(self.colors_baxter)):
            color_val = self.bgr_baxter.get(colors_reversed[c])
            col = (int(color_val[0]),int(color_val[1]),int(color_val[2]))
            cv2.circle(img, coordinates[c], radii_reversed[c], col, -1)

        # add noisy blobs
        cv2.circle(img, (5,5), 7, (0, 0, 255), -1)
        cv2.circle(img, (200, 100), 8, (0, 0, 255), -1)
        cv2.circle(img, (100,150), 7, (0, 255, 0), -1)
        cv2.circle(img, (450,150), 5, (255, 0, 0), -1)
        cv2.circle(img, (50,440), 8, (0, 255, 255), -1)

        # cv2.imshow('',img)
        # cv2.waitKey(0)

        # detect colors
        colors_of_interest = self.colors_baxter
        hanoi_board = bd.Board()
        centers_x, centers_y, widths, heights, rotations, found_colors, found_contours = bf.getBoundingBoxes(img,
                                                                                                             self.hsv_baxter,
                                                                                                             colors_of_interest)
        # make disks from colors
        all_disks = []
        for ind,found in enumerate(found_colors):
            all_disks.append(dk.DiskNew(centers_x[ind], centers_y[ind], found, ind+1))
        hanoi_board.determineBoardLayout(False, all_disks)

        # test if all disks were found
        self.assertEqual(len(found_colors),len(colors_of_interest), 'Not all disks could be found')

        # test
        truth = OrderedDict() # left, middle, right
        truth['left'] = ['dark_blue','green','red']
        truth['middle'] = ['blue','yellow','pink']
        truth['right'] = ['dark_green','orange']

        # test left tower membership
        for ind,disk in enumerate(truth['left']):
            self.assertEqual(disk,hanoi_board.left_tower[ind].color,'Error detecting '+disk+' disk on left tower')

        # test middle tower membership
        for ind,disk in enumerate(truth['middle']):
            self.assertEqual(disk,hanoi_board.middle_tower[ind].color,'Error detecting '+disk+' disk on middle tower')

        # test right tower membership
        for ind,disk in enumerate(truth['right']):
            self.assertEqual(disk,hanoi_board.right_tower[ind].color,'Error detecting '+disk+' disk on right tower')


