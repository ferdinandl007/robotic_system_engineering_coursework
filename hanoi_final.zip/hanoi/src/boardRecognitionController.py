#!/usr/bin/env python

import rospy
from sensor_msgs.msg import Image
from hanoi.msg import Blobs
from hanoi.msg import Disk
from hanoi.msg import Board
import cv2
import DiskNew as dk
import Board as bd
opencv_2 = cv2.__version__.startswith('2')


# initializations
MAX_NUM_DISKS = 10
string_col = rospy.get_param("/hanoi_colors")
hanoi_colors = string_col.split(',')
latest_complete_bounds = 0  # last position of both bounds


# publlisher to board state (disks)
boardStatePub = rospy.Publisher('/hanoi/boardState', Board)


def callbackBlobs(data):
    global latest_complete_bounds, hanoi_board
    hanoi_board = bd.Board()    # initialize clean board class

    # save last complete bounds state
    if len(data.bounds) == 2:
        latest_complete_bounds = data.bounds

    # make disks info based on the detected color blobs
    # coord_x,coord_y,disk_color,size (theoretical size)
    found_disks = []
    for d in range(len(data.blobs)):
        found_disks.append(dk.DiskNew(data.blobs[d].coord_x, data.blobs[d].coord_y, data.blobs[d].disk_color, data.blobs[d].size))

    # get board state (disk placement on board) based on board bounds
    hanoi_board.determineBoardLayout(data.bounds, found_disks)

    # make Board message and publish it
    board_msg = Board()
    for l in hanoi_board.left_tower:
        disk = Disk(l.color,l.size)
        board_msg.left.append(disk)
    for m in hanoi_board.middle_tower:
        disk = Disk(m.color,m.size)
        board_msg.middle.append(disk)
    for r in hanoi_board.right_tower:
        disk = Disk(r.color,r.size)
        board_msg.right.append(disk)
    boardStatePub.publish(board_msg)


if __name__ == "__main__":

    # create node
    rospy.init_node('boardRecognitionController', anonymous=True)

    # create subscriber to board configuration topic
    boardConfigSub = rospy.Subscriber('/hanoi/boardConfiguration', Blobs, callbackBlobs)

    # create subscriber to the right hand camera
    # uni: '/cameras/right_hand_camera/image'
    # home: '/cameras2/right_hand_camera/image'
    cameraSub = rospy.Subscriber('/cameras/right_hand_camera/image', Image)

    # prevents program from exiting, allowing subscribers and publishers to keep operating
    rospy.spin()
