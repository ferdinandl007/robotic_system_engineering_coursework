class DiskNew:
    
    def __init__(self,x,y,col,s):
        self.center_x = x
        self.center_y = y
        self.color = col
        self.size = s
