#!/usr/bin/env python

import rospy
from std_msgs.msg import String
from std_msgs.msg import Int8

# initializations
ALLOWED_WRONG_MOVES = 3
game_ended_string = "Game over. Too many wrong moves."


# will publish to speech node to tell user where to move what
feedbackPub = rospy.Publisher('/hanoi/userFeedback',String)


# will publish to topic to warn other nodes what is the game running state
# 0 = game is not running / waiting for player to engage
# 1 = game is running
# 2 = game is idle (end game interaction needs to take place)
# 3 = game needs board rearrangement
# 4 = no game setup (board is missing)
gameRunningPub = rospy.Publisher('/hanoi/gameRunning', Int8)


# will publish to topic to warn other nodes what is the game end state
# 0 = user informed of score
# 1 = user not informed of score
# 2 = user is not there
gameEndStatePub = rospy.Publisher('/hanoi/gameEndState', Int8)


def callbackWrongMoveCount(data):
    global ALLOWED_WRONG_MOVES

    # when the number of allowed wrong moves is passed, terminate game
    if data.data > ALLOWED_WRONG_MOVES:

        # first warn user that the game is over
        rospy.loginfo("Game over.Allowed wrong moves exceeded. Set game to idle (player interaction)")
        feedbackPub.publish(game_ended_string)

        # 2 = game is idle (end game interaction needs to take place)
        gameRunningPub.publish(2)
        # 1 = user not informed of score
        gameEndStatePub.publish(1)


if __name__ == "__main__":

    # create node
    rospy.init_node('illegalMoveController', anonymous=True)

    # create subscriber to the valid move topic
    wrongMovesSub = rospy.Subscriber('/hanoi/wrongMoves', Int8, callbackWrongMoveCount)

    # prevents program from exiting, allowing subscribers and publishers to keep operating
    rospy.spin()
