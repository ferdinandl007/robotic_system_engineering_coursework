#!/usr/bin/env python

import rospy
import baxter_interface
from std_msgs.msg import String
from std_msgs.msg import Int8
import time


# initializations
feedback_string = "Quitting game."
game_running = None


# will publish to topic to warn that game is terminated
feedbackPub = rospy.Publisher('/hanoi/userFeedback', String)


# will publish to topic to warn other nodes what is the game running state
# 0 = game is not running / waiting for player to engage
# 1 = game is running
# 2 = game is idle (end game interaction needs to take place)
# 3 = game needs board rearrangement
# 4 = no game setup (board is missing)
gameRunningPub = rospy.Publisher('/hanoi/gameRunning', Int8)


# will publish to topic to warn other nodes what is the game end state
# 0 = user informed of score
# 1 = user not informed of score
# 2 = user is not there
gameEndStatePub = rospy.Publisher('/hanoi/gameEndState', Int8)


# updates the state of the game when other nodes change it
def callbackGameStart(data):
    global game_running
    game_running = data.data


# if right-arm button 1, quit game
def callbackQuitGame(v):
    if v == True:
        rospy.loginfo("Game terminated by player. Need to do player interaction")
        feedbackPub.publish(feedback_string)
        gameEndStatePub.publish(1)  # 1 since user quits game -> game not done -> can't compute score
        time.sleep(0.1)
        gameRunningPub.publish(3)   #3 = board needs rearrangement


if __name__ == "__main__":

    # create node
    rospy.init_node('quitGameController', anonymous=True)

    # create subscriber to the game state
    gameRunningSub = rospy.Subscriber('/hanoi/gameRunning', Int8, callbackGameStart)

    # create subscriber to the right arm button
    rightArmNav = baxter_interface.Navigator('right')

    # check for right arm button 1 press for QUIT GAME
    rightArmNav.button1_changed.connect(callbackQuitGame)

    # prevents program from exiting, allowing subscribers and publishers to keep operating
    rospy.spin()
