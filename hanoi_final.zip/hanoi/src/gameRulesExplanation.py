#!/usr/bin/env python

import rospy
import baxter_interface
from std_msgs.msg import String

# initializations
game_rules_string = "You have to move all the disks over to opposite tower, without placing a larger disk onto a smaller disk."


# will publish to speech node to explain to user game rules
feedbackPub = rospy.Publisher('/hanoi/userFeedback',String)


def sendGameRulesExplanation(v):
    # if button is pressed
    if v == True:
        print('button pushed')
        feedbackPub.publish(game_rules_string)


if __name__ == "__main__":

    # create node
    rospy.init_node('gameRulesExplanation', anonymous=True)

    # create subscriber to the right arm button
    rightArmNav = baxter_interface.Navigator('right')

    # check for left arm button 1 press for game rules explanation
    rightArmNav.button0_changed.connect(sendGameRulesExplanation)

    # prevents program from exiting, allowing subscribers and publishers to keep operating
    rospy.spin()
