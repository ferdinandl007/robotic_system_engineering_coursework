#!/usr/bin/env python

import rospy
import baxter_interface
from std_msgs.msg import String
from std_msgs.msg import Int8
from hanoi.msg import Moves


# initializations
left_tower = 0
middle_tower = 1
right_tower = 2
next_move = None
command = None
origin = None
destination = None


# will publish to speech node to tell user where to move what
movementLAPub = rospy.Publisher('/hanoi/movementLA',String)

# will publish to speech node to tell user where to move what, once the button is pressed
feedbackPub = rospy.Publisher('/hanoi/userFeedback',String)


# 0 = game is not running / waiting player to engage
# 1 = game is running
# 2 = game is idle (end game interaction needs to take place)
# 3 = game needs board rearrangement
# 4 = no game setup (board is missing)
game_running = None


def updateGameRunning(data):
    global game_running
    game_running = data.data

    # if game has been reinitialized, clean up variables
    if game_running == 1:
        reinitializeStates()


def reinitializeStates():
    global next_move, command, origin, destination
    next_move = None
    command = None
    origin = None
    destination = None


# decodes tower numbers to tower names for movement command
def decodeSolution(move_string):
    global left_tower,middle_tower,right_tower
    string = move_string.split(" ")
    disk_num = int(string[1])
    origin_tower_num = int(string[3])
    destination_tower_num = int(string[5])

    # decode origing
    command = "Move disk from "
    if origin_tower_num == left_tower:
        command = command+"left tower"
    elif origin_tower_num == middle_tower:
        command = command + "middle tower"
    else:
        command = command + "right tower"

    # decode destination
    command = command + " to "
    if destination_tower_num == left_tower:
        command = command + "left tower"
    elif destination_tower_num == middle_tower:
        command = command + "middle tower"
    else:
        command = command + "right tower"

    return command,origin_tower_num,destination_tower_num


def callbackNextMove(data):
    global next_move,command,origin,destination
    try:
        next_move = data.moves[0]
        command,origin,destination = decodeSolution(next_move)
        rospy.loginfo("We have a next move")
    except IndexError:
        # there are no more moves
        next_move = "END"
        rospy.loginfo("We don't have a next move")
    except:
        # if there is another problem
        next_move = "PROBLEM"
        rospy.loginfo("We have a problem in next move.")


def callbackHint(v):
    global next_move, command, origin, destination, game_running
    init = (next_move is not None) and (command is not None) and (origin is not None) and (destination is not None)

    # if button is pressed and game is running
    if (v == True) and (game_running == 1):
        # and hints have been computed
        if init:
            name_of_file = str(origin)+"-"+str(destination)
            rospy.loginfo("The next move is: "+command)
            rospy.loginfo("Move file: " + name_of_file)
            movementLAPub.publish(name_of_file)
            #TODO SLEEP HERE
            feedbackPub.publish(command)
        # hits not computed (there is no more next move)
        else:
            feedbackPub.publish('No more moves.')


if __name__ == "__main__":

    # create node
    rospy.init_node('provideHintAlgorithm', anonymous=True)

    # create subscriber to the game state
    gameRunningSub = rospy.Subscriber('/hanoi/gameRunning', Int8, updateGameRunning)

    # create subscriber to the valid move topic
    movesSub = rospy.Subscriber('/hanoi/nextMove', Moves, callbackNextMove)

    # create subscriber to the left arm button
    leftArmNav = baxter_interface.Navigator('left')

    # check for left arm button 1 press for YES HINT
    leftArmNav.button1_changed.connect(callbackHint)

    # prevents program from exiting, allowing subscribers and publishers to keep operating
    rospy.spin()
