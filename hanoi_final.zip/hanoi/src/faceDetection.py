#!/usr/bin/env python


import rospy
from sensor_msgs.msg import Image
from std_msgs.msg import Bool
from std_msgs.msg import Int8
from cv_bridge import CvBridge, CvBridgeError
import cv2
import numpy as np


# initializations
path_casc = rospy.get_param("/path_casc")
faceCascade = cv2.CascadeClassifier(path_casc)
bridge = CvBridge()
game_running = 0
img_count = 0
PROCESS_EVERY = 5
VIEW_SIZE = 0.3     # percentage of width -> circle to detect faces in
min_size = 50

# publisher to Baxter's screen
displayImagePub = rospy.Publisher('/robot/xdisplay', Image)


# publisher to which we post whether a face has been detected or not
faceDetectedPub = rospy.Publisher('/hanoi/faceDetected', Bool)


def gameRunningCallback(data):
    global game_running
    game_running = data.data


# camera subscriber callback
def imageCallback(data):
    global img_count

    # read every PROCESS_EVERY frames
    # otherwise too slow
    img_count += 1
    if img_count % PROCESS_EVERY > 0:
        return

    # restrict area
    cv_image = bridge.imgmsg_to_cv2(data, "bgr8")
    img_h = cv_image.shape[0]
    img_w = cv_image.shape[1]
    mask = np.zeros((img_h, img_w), np.uint8)
    mid_h = int(img_h/2)
    mid_w = int(img_w/2)
    cv2.circle(mask, (mid_w, mid_h), int(VIEW_SIZE*img_w), 255, -1)
    masked = cv2.bitwise_and(cv_image, cv_image, mask=mask)


    # detect faces on the masked image to avoid detecting faces in the window
    gray = cv2.cvtColor(masked, cv2.COLOR_BGR2GRAY)
    faces = faceCascade.detectMultiScale(
        gray,
        scaleFactor=1.1,
        minNeighbors=5,
        minSize=(30, 30),
        flags=cv2.CASCADE_SCALE_IMAGE)

    # minimum face size
    hh = 0
    ww = 0

    # Draw a rectangle around the faces
    for (x, y, w, h) in faces:
        cv2.rectangle(masked, (x, y), (x+w, y+h), (0, 255, 0), 2)
        if h*w > hh*ww:
            ww = w
            hh = h

    # Display the resulting frame
    cv2.imshow("Head Camera Feed", masked)
    cv2.waitKey(1) # needed for cv2.imshow to take effect. REMOVE otherwise

    # check if faces detected
    if len(faces) != 0:
        # if face is a particular size
        if hh > min_size and ww > min_size:
            faceDetectedPub.publish(True)   # face is detected

        else:
            faceDetectedPub.publish(False)  # face is not detected
    else:
        faceDetectedPub.publish(False)  # face is not detected

    # display faces to Baxter screen if we are in greeting mode
    outData = bridge.cv2_to_imgmsg(cv_image, "bgr8")
    if game_running == 0:
        displayImagePub.publish(outData)


if __name__ == '__main__':

    rospy.init_node('faceDetection', anonymous=True)

    # create subscriber to the right hand camera, each frame recieved calls the callback function
    # home: 'cameras/faceCamera'
    # uni: '/cameras/head_camera/image'
    camera_sub = rospy.Subscriber('/cameras/head_camera/image', Image, imageCallback)

    # subscriber to the game running
    gameRunningSub = rospy.Subscriber('/hanoi/gameRunning', Int8, gameRunningCallback)

    # prevents program from exiting, allowing subscribers and publishers to keep operating
    rospy.spin()

