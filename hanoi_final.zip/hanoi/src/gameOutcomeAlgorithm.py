#!/usr/bin/env python

import rospy
from std_msgs.msg import String
from std_msgs.msg import Float32
from std_msgs.msg import Int8


# initializations
path_scores = rospy.get_param("/path_scores")
game_running = None
score = None
wrong_moves = 0


# will publish to topic to warn other nodes what is the game end state
# 0 = user informed of score
# 1 = user not informed of score
# 2 = user is not there
gameEndStatePub = rospy.Publisher('/hanoi/gameEndState', Int8)


# will publish to topic to inform user about his score, wrong moves, ranking
feedbackPub = rospy.Publisher('/hanoi/userFeedback', String)


def reinitializeStates():
    global score, wrong_moves
    score = None
    wrong_moves = 0


# update game score
def callbackScore(data):
    global score
    score = int(data.data)


# will write score of player in database
def writeScore(current_score, path_scores):
    try:
        file = open(path_scores, "a+")
        file.write(str(current_score)+",")
        file.close()
        return True
    except:
        return False


# will return ranking: (x,y) means x out of y
def getRanking(current_score, path_scores):
    try:
        # get scores
        filename = open(path_scores, "r")
        all_scores = filename.read()
        all_scores = all_scores[:-1]
        all_scores = all_scores.split(",")

        # turn into correct type
        for i in range(len(all_scores)):
            if all_scores[i] == "None":
                continue
            all_scores[i] = float(all_scores[i])

        # sort scores, get ranking
        sorted_scores = sorted(all_scores)
        position = sorted_scores.index(current_score) + 1
        rospy.loginfo("Could read the score.")
        return position,len(all_scores)

    # if not possible to read, return 0
    except:
        rospy.loginfo("Could not read score")
        return 0,0


# computes ranking of player based on time to finish, returns position (1st, 2nd etc)
def computeRanking(new_score, path_score):

    # 1. save score
    rospy.loginfo("Trying to write score "+str(new_score))
    success = writeScore(new_score,path_score)

    if success:
        # 2. determine ranking, save locally
        pos,out_of = getRanking(new_score,path_score)
        result_string = str(pos) + " out of " + str(out_of)
        return result_string
    else:
        return " undetermined "


# update the number of wrong moves made by the player
def callbackWrongMoves(data):
    global wrong_moves
    wrong_moves = data.data


def informPlayer(data):
    global game_running, wrong_moves, score, path_score

    # update game state value
    game_running = data.data

    # if game = 2 => game is idle (end game interaction needs to take place)
    if (game_running == 2) and (score is not None):
        rospy.loginfo("Game running is 2 now")

        # 1. compute ranking
        ranking = computeRanking(score,path_scores)

        # 2. tell user score, wrong moves and ranking
        # maybe sleep for a while until user is informed
        result_string = "You took "+str(int(score))+" minutes and made "\
                        +str(int(wrong_moves))+" wrong moves. You rank "\
                        +ranking+" players."
        # time.sleep(2)   # sleep, otherwise won't speak because move feedback speaks
        rospy.loginfo(result_string)
        feedbackPub.publish(result_string)

        # 3. sets game_end_state = 0 (user informed of score)
        gameEndStatePub.publish(0)

    # if game has been reinitialized, clean up variables
    elif game_running == 1:
        reinitializeStates()


if __name__ == "__main__":

    # create node
    rospy.init_node('gameOutcomeAlgorithm', anonymous=True)

    # create subscriber to the game outcome topic
    gameOutcomeSub = rospy.Subscriber('/hanoi/gameOutcome', Float32, callbackScore)

    # create subscriber to the number of wrong moves topic
    wrongMovesSub = rospy.Subscriber('/hanoi/wrongMoves', Int8, callbackWrongMoves)

    # create subscriber to the game state
    gameRunningSub = rospy.Subscriber('/hanoi/gameRunning', Int8, informPlayer)

    # prevents program from exiting, allowing subscribers and publishers to keep operating
    rospy.spin()
