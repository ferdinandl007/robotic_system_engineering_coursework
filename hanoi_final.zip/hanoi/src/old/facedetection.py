#!/usr/bin/env python

from espeak import espeak
import rospy
from sensor_msgs.msg import Image
from std_msgs.msg import Bool
from cv_bridge import CvBridge, CvBridgeError
import cv2

cascPath = "/home/baxter/ros_ws/src/hanoi/src/haarcascade_frontalface_default.xml"
faceCascade = cv2.CascadeClassifier(cascPath)
espeak.set_voice("en")
stranger = 20

displayPubImage = rospy.Publisher('/robot/xdisplay',Image)



# publisher to which we post whether a face has been detected or not
displayPubBool = rospy.Publisher('/hanoi/faceDetected',Bool)

def sayHello():
    global stranger
    if stranger == 20:
    	espeak.synth("Hello there stranger!")
	stranger = 0       
    stranger += 1	

#callback function for camera subscriber, called by the camera subscriber for every frame.
def callback(data):


    bridge = CvBridge()
    
    #Convert incoming image from a ROS image message to a CV image that open CV can process.
    cv_image = bridge.imgmsg_to_cv2(data, "bgr8")

    #Display the converted cv image, this is the raw camera feed data.
   

    # TODO detect faces

    gray = cv2.cvtColor(cv_image, cv2.COLOR_BGR2GRAY)

    faces = faceCascade.detectMultiScale(
        gray,
        scaleFactor=1.1,
        minNeighbors=5,
        minSize=(30, 30),
        flags=cv2.CASCADE_SCALE_IMAGE
    )

    hh = 0
    ww = 0
    # Draw a rectangle around the faces
    for (x, y, w, h) in faces:
        cv2.rectangle(cv_image, (x, y), (x+w, y+h), (0, 255, 0), 2)
	#print(h,w)
        ww = w
        hh = h
	

    # Display the resulting frame
    cv2.imshow("Head Camera Feed", cv_image)
    
    cv2.waitKey(1) # needed for cv2.imshow to take effect. REMOVE otherwise
    #Publish detected true/false
    if hh > 85 and ww > 85 :
   	 if len(faces) != 0:
	     print('length ',str(len(faces)))
	     sayHello()
    	     displayPubBool.publish( True )
		
		
   	 else:
    		displayPubBool.publish( False )
		stranger = False

    outData = bridge.cv2_to_imgmsg(cv_image, "bgr8")
    displayPubImage.publish( outData )
  




if __name__ == '__main__':
    rospy.init_node('facedetection', anonymous=True)

#create subscriber to the right hand camera, each frame recieved calls the callback function
camera_sub = rospy.Subscriber("/cameras/head_camera/image",Image,callback)

#prevents program from exiting, allowing subscribers and publishers to keep operating
#in our case that is the camera subscriber and the image processing callback function
rospy.spin()

