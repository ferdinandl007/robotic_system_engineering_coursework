#!/usr/bin/env python

import rospy
import os
import time



def getTiming(SECS):
    ros_ver = rospy.__path__
    if 'groovy' in ros_ver[0]:
        return rospy.Time(SECS)
    elif 'kinetic' in ros_ver[0]:
        return rospy.Duration(SECS)
    else:
        return "Neither groovy nor kinetic"


def doThis(event):
    print("I was called after SECS seconds")


if __name__ == "__main__":

    # create node
    rospy.init_node('testingTime', anonymous=True)


    SECS = int(10)

    timer = rospy.Timer(getTiming(SECS),doThis,oneshot=True)

    # prevents program from exiting, allowing subscribers and publishers to keep operating
    # in our case that is the camera subscriber and the image processing callback function
    rospy.spin()

