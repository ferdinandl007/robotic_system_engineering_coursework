#!/usr/bin/env python

import rospy
from std_msgs.msg import Bool
from std_msgs.msg import Int16
from baxter_core_msgs.msg import DigitalIOState

nodPub = rospy.Publisher('/robot/head/command_head_nod',Bool)
gameRunningPub = rospy.Publisher('/hanoi/gamerunning',Int16)


faceSpotted = False
buttonPress = False


def faceCallback(data):
    global faceSpotted
    rospy.loginfo("Face: " + str(data.data))
    if faceSpotted==False and data.data==True and buttonPress==False :
	nodPub.publish( True )
        rospy.loginfo("Nodding")
    	faceSpotted = True
	print('')
    if faceSpotted==True and buttonPress==False:
																
        nodPub.publish( True )
        rospy.loginfo("Nodding")



def buttonCallback(data):
    global faceSpotted
    global buttonPress
    #rospy.loginfo("Button: " + str(data.state))
    if faceSpotted==True and data.state==1:
	buttonPress = True        
	faceSpotted = False
        gameRunningPub.publish(1)
        nodPub.publish( False )
        rospy.loginfo("Stop nodding, game has started")


face_sub = rospy.Subscriber("/hanoi/faceDetected",Bool,faceCallback)
button_sub = rospy.Subscriber("/robot/digital_io/left_itb_button0/state",DigitalIOState,buttonCallback)



if __name__ == '__main__':
    rospy.init_node('greetingcontrol', anonymous=True)

    #prevents program from exiting, allowing subscribers and publishers to keep operating
    rospy.spin()

