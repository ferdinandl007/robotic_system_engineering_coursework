#!/usr/bin/env python

import rospy
import baxter_interface
from std_msgs.msg import String
from std_msgs.msg import Int8
from hanoi.msg import FilteredBoard
from std_msgs.msg import Bool


# initializations
Y_SECS = 30  # seconds to wait until terminating game
timer_Y_started = False
timerY = None
face_detected = False
i_am_here = False
game_running = None
feedback_string = "Terminating game."


# will publish to topic to warn that game is terminated
feedbackPub = rospy.Publisher('/hanoi/userFeedback', String)


# 0 = game is not running / waiting for player to engage
# 1 = game is running
# 2 = game is idle (end game interaction needs to take place)
# 3 = game needs board rearrangement
# 4 = no game setup (board is missing)
gameRunningPub = rospy.Publisher('/hanoi/gameRunning', Int8)


# will publish to topic to warn other nodes what is the game end state
# 0 = user informed of score
# 1 = user not informed of score
# 2 = user is not there
gameEndStatePub = rospy.Publisher('/hanoi/gameEndState', Int8)


def reinitializeStates():
    global timer_Y_started, timerY, face_detected, i_am_here
    timer_Y_started = False
    if timerY is not None:
        timerY.shutdown()
    timerY = None
    face_detected = False
    i_am_here = False


# updates the state of the game when other nodes change it
def gameRunningUpdate(data):
    global game_running
    game_running = data.data

    # if game has benn reinitialized, clean up variables
    if game_running == 1:
        reinitializeStates()


# checks if a face is detected
def faceCallback(data):
    global face_detected
    face_detected = data.data


# if player did not have time to push button but to make another move
# shut down timer
def callbackNewMove(data):
    global timerY,timer_Y_started
    if timerY is not None:
        timerY.shutdown()
        timer_Y_started = False


# if either left-arm button 1 or left-arm button 2 pressed, let game continue
def callbackResponse(v):
    global timerY, timer_Y_started, i_am_here, Y_SECS
    # check if timer is not None, otherwise will get triggered by the same button press for providing the hint
    if v == True and (timerY is not None) and (timer_Y_started is True):
        # let game continue
        i_am_here = True
        timerY.shutdown()
        timer_Y_started = False


# if Y_SECS seconds pass since delay detected, and no face and no button, stop game
def callbackTerminate(event):
    global timerY, timer_Y_started, feedback_string, game_running, face_detected, i_am_here

    # no face detected, no button press
    if i_am_here == False and face_detected == False:
        timerY.shutdown()
        timer_Y_started = False
        game_running = None
        rospy.loginfo("No one is here. Game needs rearrangement")
        feedbackPub.publish(feedback_string)    # warn that game is terminated
        gameEndStatePub.publish(2)              # 2 = user is not there
        gameRunningPub.publish(3)               # 3 = game needs board rearrangement


# once delay is detected, starts a timer to allow the user to press either left-arm button 1 or left-arm button 2
def callbackDelay(data):
    global game_running, timer_Y_started, timerY, Y_SECS, i_am_here

    # start timer only if game is running
    if game_running == 1:

        rospy.loginfo("Start timer to allow user to press YES/NO for hint.")

        # start timer if none was started (FOR THE FIRST TIME delay is sent)
        if timerY is None:
            timerY = rospy.Timer(rospy.Duration(Y_SECS), callbackTerminate, oneshot=True)
            timer_Y_started = True
            i_am_here = False

        # if a timerY exists, and is not started, start it again (when delay is SENT AGAIN)
        if (timerY is not None) and (timer_Y_started == False):
            timerY = rospy.Timer(rospy.Duration(Y_SECS), callbackTerminate, oneshot=True)
            timer_Y_started = True
            i_am_here = False


if __name__ == "__main__":

    # create node
    rospy.init_node('terminateGameController', anonymous=True)

    # create subscriber to delay topic
    delaySub = rospy.Subscriber('/hanoi/delay', Bool, callbackDelay)

    # create subscriber to the game state
    gameRunningSub = rospy.Subscriber('/hanoi/gameRunning', Int8, gameRunningUpdate)

    # create subscriber to face detection
    faceSub = rospy.Subscriber("/hanoi/faceDetected", Bool, faceCallback)

    # create subscriber to the filtered board topic
    filteredBoardSub = rospy.Subscriber('/hanoi/filteredBoardState', FilteredBoard, callbackNewMove)

    # create subscriber to the left arm button
    leftArmNav = baxter_interface.Navigator('left')

    # check for left arm button 1 press for YES HINT
    leftArmNav.button1_changed.connect(callbackResponse)

    # check for left arm button 2 press for NO HINT
    leftArmNav.button2_changed.connect(callbackResponse)

    # prevents program from exiting, allowing subscribers and publishers to keep operating
    rospy.spin()
