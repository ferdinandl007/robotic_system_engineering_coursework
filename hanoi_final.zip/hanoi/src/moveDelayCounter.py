#!/usr/bin/env python

import rospy
from std_msgs.msg import String
from std_msgs.msg import Int8
from hanoi.msg import FilteredBoard
from std_msgs.msg import Bool


# will publish to topic to ask user if he wants a hint
feedbackPub = rospy.Publisher('/hanoi/userFeedback', String)


# will publish to delay topic to warn other nodes that a move was not been done
delayPub = rospy.Publisher('/hanoi/delay', Bool)


# initializations
W_SECS = 30  # seconds to wait until offer to help
game_running = None
timer_W_started = False
timerW = None
feedback_string = "For hint, press left-arm button 1, otherwise button 2"


def reinitializeStates():
    global timer_W_started, timerW
    if timerW is not None:
        timerW.shutdown()
    timer_W_started = False
    timerW = None


# updates the state of the game when other nodes change it
def updateGameRunning(data):
    global game_running
    game_running = data.data

    # if game has been reinitialized, clean up variables
    if game_running == 1:
        reinitializeStates()


# if W_SECS seconds pass since the last board change, it will ask user if he needs help
def callbackTimer(event):
    global timerW, timer_W_started, feedback_string, game_running
    timerW.shutdown()
    timer_W_started = False

    # publish only if we are playing the game
    if game_running == 1:
        rospy.loginfo("Delay detected.")
        delayPub.publish(True)
        feedbackPub.publish(feedback_string)


# once a new board has been published, it starts a new timer if game is running (1) and no other timer started
def callbackCountDelay(data):
    global game_running, timer_W_started, timerW

    # count delay only if game is running:
    if game_running == 1:
        rospy.loginfo("New filtered board. Starting to count " + str(W_SECS) + " seconds")

        # for the first board configuration
        if timerW is None:
            timerW = rospy.Timer(rospy.Duration(W_SECS), callbackTimer, oneshot=True)
            timer_W_started = True

        # for each new board configuration, restart timer
        elif timerW is not None:
            timerW.shutdown()
            timer_W_started = False
            timerW = rospy.Timer(rospy.Duration(W_SECS), callbackTimer, oneshot=True)
            timer_W_started = True


if __name__ == "__main__":

    # create node
    rospy.init_node('moveDelayCounter', anonymous=True)

    # create subscriber to the filtered board config
    filteredBoardSub = rospy.Subscriber('/hanoi/filteredBoardState', FilteredBoard, callbackCountDelay)

    # create subscriber to the game state
    gameRunningSub = rospy.Subscriber('/hanoi/gameRunning', Int8, updateGameRunning)

    # prevents program from exiting, allowing subscribers and publishers to keep operating
    rospy.spin()
