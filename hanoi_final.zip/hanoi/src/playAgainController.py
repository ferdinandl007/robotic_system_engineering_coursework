#!/usr/bin/env python

import rospy
import baxter_interface
from std_msgs.msg import String
from std_msgs.msg import Int8

# will be ACTIVE if:
# player has made more than ALLOWED_WRONG_MOVES (illegalMoveController publishes)
# player quit the game by button press (quitGameController publishes)
# player has completed the game (gameEndController publishes)
# board needs rearrangement
# board does not exist


# initializations
ANSWER_SECS = 20    # how long to wait for user to press replay button
CHECK_SECS = 1      # how often to check values of game_end_state and game_running
play_string = "If you want to play another game, press right-arm button 2."
rearrange_string = "Please rearrange board."
no_setup_string = "The disks are missing. Terminating game."
game_end_state = None
game_running = None
timer_states_check = None
wants_replay = False
timer_answer = None


# 0 = game is not running / waiting player to engage
# 1 = game is running
# 2 = game is idle (end game interaction needs to take place)
# 3 = game needs board rearrangement
# 4 = no game setup (board is missing)
gameRunningPub = rospy.Publisher('/hanoi/gameRunning', Int8)


# will publish to topic to ask user if he wants to play again
feedbackPub = rospy.Publisher('/hanoi/userFeedback', String)


def reinitializeStates():
    global game_end_state, timer_states_check, wants_replay, timer_answer
    game_end_state = None
    wants_replay = False
    if timer_answer is not None:
        timer_answer.shutdown()
    timer_answer = None
    if timer_states_check is not None:
        timer_states_check.shutdown()
    timer_states_check = None


def updateGameEndState(data):
    global game_end_state
    game_end_state = data.data

    # if game has been reinitialized, clean up variables
    if game_running == 1:
        reinitializeStates()


def updateGameRunning(data):
    global game_running,timer_states_check
    game_running = data.data

    # if game is idle (user interaction) or board needs rearrangement
    if game_running == 2 or game_running == 3:
        # start timer to later check game_end_state as well
        timer_states_check = rospy.Timer(rospy.Duration(CHECK_SECS), checkStates, oneshot=False)

    # if the board is missing, inform user, terminate game, wait for rearrangement
    if game_running == 4:
        feedbackPub.publish(no_setup_string)
        checkAnswer(None)



def checkStates(event):
    global game_running, game_end_state,play_string,timer_states_check,timer_answer,ANSWER_SECS
    # if user interaction needs to take place and user is either informed or not informed
    # or if board needs rearrangement
    if ((game_running == 2) and (game_end_state == 0 or game_end_state == 1)) or game_running == 3:

        # stop timer for states checking
        if timer_states_check is not None:
            timer_states_check.shutdown()

        # ask if he wants to play again
        rospy.loginfo(play_string)
        feedbackPub.publish(play_string)

        # start timer to allow answer
        timer_answer = rospy.Timer(rospy.Duration(ANSWER_SECS), checkAnswer, oneshot=True)


def checkAnswer(event):
    # when ANSWER_SECS seconds have passed, ask for board rearrangement
    feedbackPub.publish(rearrange_string)
    rospy.loginfo('Answer checked')


def wantsReplay(v):
    global wants_replay,timer_answer
    # if button is pressed, player wants to replay
    if v == True:
        # stop timer to allow answer
        if timer_answer is not None:
            timer_answer.shutdown()

        # set the flag to replay
        wants_replay = True
        rospy.loginfo('Player wants to replay')
        checkAnswer(None)


def boardRearranged(v):
    # if board has been rearranged
    if v == True:
        # and player wants to replay
        if wants_replay:
            gameRunningPub.publish(1)
            rospy.loginfo("Game running =1")
        # if player does not want to replay
        else:
            gameRunningPub.publish(0)
            rospy.loginfo("Game running =0")


if __name__ == "__main__":

    # create node
    rospy.init_node('playAgainController', anonymous=True)

    # create subscriber to the game este state topic
    gameEndStateSub = rospy.Subscriber('/hanoi/gameEndState', Int8, updateGameEndState)

    # create subscriber to the game state
    gameRunningSub = rospy.Subscriber('/hanoi/gameRunning', Int8, updateGameRunning)

    # create subscriber to the left arm button
    rightArmNav = baxter_interface.Navigator('right')

    # check for right arm button 2 press for REPLAY GAME
    rightArmNav.button2_changed.connect(wantsReplay)

    # create subscriber to the left arm button
    rightTorsoNav = baxter_interface.Navigator('torso_right')

    # check for right torso button 2 press for BOARD HAS BEEN REARRANGED
    rightTorsoNav.button2_changed.connect(boardRearranged)

    # prevents program from exiting, allowing subscribers and publishers to keep operating
    rospy.spin()
