import argparse
import socket
import sys

import rospy
import rosgraph

import std_srvs.srv

from baxter_core_msgs.srv import (ListCameras,)
from baxter_interface.camera import CameraController



def open_camera(camera, res, fps):
    cam = CameraController(camera)
    cam.resolution = res
    cam.fps = fps
    print(camera)
    print('resolution : ' + str(cam.resolution))
    cam.open()


def open_camera_hand(camera, res, fps, exp):
    cam = CameraController(camera)
    cam.resolution = res
    cam.fps = fps
    cam.exposure = exp
    print(camera)
    print('exposure: '+str(cam.exposure))
    print('fps: ' + str(cam.fps))
    print('resolution : ' + str(cam.resolution))
    cam.open()


def open_camera_head(camera, res, fps):
    cam = CameraController(camera)
    cam.resolution = res
    cam.fps = fps
    print(camera)
    print('fps: ' + str(cam.fps))
    print('resolution : ' + str(cam.resolution))
    cam.open()


def close_camera(camera):
    cam = CameraController(camera)
    cam.close()



if __name__ == "__main__":

    # default hand cameras: 320x200 size and 25 fps.

    # supported resolutions
    # 1280x800, 960x600, 640x400, 480x300, 384x240, 320x200
    # 1280x800 max refresh rate 14.1 fps
    # 960x600 max refresh rate 23.8 fps
    # 640x400 max refresh rate 27.8 fps

    # Camera Exposure.Valid range is 0 - 100 or CameraController.CONTROL_AUTO
    # Camera gain.  Range is 0-79 or CameraController.CONTROL_AUTO

    res_right = (960, 600)
    res_head = (960, 600)
    fps_right = 15
    fps_head = 10
    exp_right = 70
    exp_head = 50
    gain_right = 35
    gain_head = 35

    # close_camera('right_hand_camera')
    # close_camera('left_hand_camera')

    # open_camera_hand('right_hand_camera',res_right,fps_right,exp_right)
    open_camera_head('head_camera',res_head,fps_head)
    close_camera('right_hand_camera')
    open_camera('right_hand_camera',res_right,fps_right)


