#!/usr/bin/env python

import rospy
from std_msgs.msg import Float32
from std_msgs.msg import Int8
from hanoi.msg import Moves
import time


# will publish to topic to warn other nodes what is the game running state
# 0 = game is not running / waiting for player to engage
# 1 = game is running
# 2 = game is idle (end game interaction needs to take place)
# 3 = game needs board rearrangement
# 4 = no game setup (board is missing)
gameRunningPub = rospy.Publisher('/hanoi/gameRunning', Int8)


# will publish to topic the number of minutes required to complete the game
gameOutcomePub = rospy.Publisher('/hanoi/gameOutcome', Float32)


# initializations
start_time = None
next_move = None
game_running = None

def reinitializeStates():
    global start_time, next_move
    start_time = time.time()
    next_move = None


# will check if there are no more moves (game completed)
def checkEnd(data):
    global next_move
    try:
        # there are moves available
        next_move = data.moves[0]
    except IndexError:
        # there are no more moves
        next_move = "END"
        rospy.loginfo("END game")
    except:
        # if there is another problem
        next_move = "PROBLEM"
        rospy.loginfo("PROBLEM")


# updates the state of the game when other nodes change it
def callbackGameStart(data):
    global start_time, game_running

    # update game state value
    game_running = data.data
    rospy.loginfo("GmEndCtr:Game_running:" + str(game_running))

    # if game just started, clean up variables
    if game_running == 1:
        reinitializeStates()


# if the game has ended
def callbackComputeScore(data):
    global next_move, start_time, game_running

    # check if game is over
    checkEnd(data)
    if next_move == "END" and game_running <= 2:
        # compute time (score) and publih
        elapsed_time_secs = time.time() - start_time
        elapsed_time_mins = elapsed_time_secs/60
        gameOutcomePub.publish(elapsed_time_mins)
        gameRunningPub.publish(2)   # 2 = game is idle (end game interaction)


if __name__ == "__main__":

    # create node
    rospy.init_node('gameEndController', anonymous=True)

    # create subscriber to the valid move topic
    movesSub = rospy.Subscriber('/hanoi/nextMove', Moves, callbackComputeScore)

    # create subscriber to the game state
    gameRunningSub = rospy.Subscriber('/hanoi/gameRunning', Int8, callbackGameStart)

    # prevents program from exiting, allowing subscribers and publishers to keep operating
    rospy.spin()
