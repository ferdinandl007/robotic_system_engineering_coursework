#!/usr/bin/env python

import rospy
from std_msgs.msg import Bool
from std_msgs.msg import Int8
from std_msgs.msg import String
from baxter_core_msgs.msg import DigitalIOState


# initializations
faceSpotted = False
previous_face_spotted = False
buttonPress = False
game_running = 0
hello_string = "Hello!"
rules_offer_string = "Please wait for the board to be displayed. To hear the rules of the game, press right arm button 0."
offer_given = False

# will publish nod command
nodPub = rospy.Publisher('/robot/head/command_head_nod',Bool)


# will publish to gameRunning topic
gameRunningPub = rospy.Publisher('/hanoi/gameRunning', Int8)


# will publish to speech node
feedbackPub = rospy.Publisher('/hanoi/userFeedback',String)


# STATES
# 0 = game is not running / waiting player to engage
# 1 = game is running
# 2 = game is idle (end game interaction needs to take place)
# 3 = game needs board rearrangement
# 4 = no game setup (board is missing)


def reinitializeStates():
    global faceSpotted, previous_face_spotted, buttonPress
    faceSpotted = False
    previous_face_spotted = False
    buttonPress = False


def gameRunningCallback(data):
    global game_running, buttonPress, offer_given

    # if game was running or idle and current game is not running
    if game_running > 0 and data.data == 0:
        # flag that button is not pressed
        buttonPress = False

    # update game running state
    game_running = data.data

    # if game has just started, offer to explain game rules
    if (game_running == 1) and (not offer_given):
        feedbackPub.publish(rules_offer_string)
        offer_given = True

    # if game has been reinitialized, clean up variables
    if game_running == 0:
        reinitializeStates()


def faceCallback(data):
    global faceSpotted, previous_face_spotted
    faceSpotted = data.data     # true/false

    # if face is spotted and now face is spotted and the button is not pressed yet
    if faceSpotted == True and buttonPress == False:
        # start nodding
        nodPub.publish(True)
        rospy.loginfo("Nodding")

        if previous_face_spotted == False:
            feedbackPub.publish(hello_string)
            rospy.loginfo("Saying hello")

    # flag that a previous face was spotted
    previous_face_spotted = faceSpotted


def buttonCallback(data):
    global faceSpotted, buttonPress

    # if face is spotted and the button is pressed
    if faceSpotted == True and data.state == 1:

        # stop nodding
        buttonPress = True
        nodPub.publish(False)
        rospy.loginfo("Stop nodding")

        # set game running to 1 (player started the game)
        gameRunningPub.publish(1)


if __name__ == '__main__':

    rospy.init_node('greetingControl', anonymous=True)

    # subscriber to left arm button 0 (Play game)
    playGameButtonSub = rospy.Subscriber("/robot/digital_io/left_itb_button0/state", DigitalIOState, buttonCallback)

    # subscriber to face detected topic
    faceDetectedSub = rospy.Subscriber("/hanoi/faceDetected", Bool, faceCallback)

    # subscriber to the game running
    gameRunningSub = rospy.Subscriber('/hanoi/gameRunning', Int8, gameRunningCallback)

    # prevents program from exiting, allowing subscribers and publishers to keep operating
    rospy.spin()

