#!/usr/bin/env python

import rospy
from std_msgs.msg import Int8
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
from hanoi.msg import FilteredBoard
from std_msgs.msg import Bool
import validityFunctions as vf
import blobFunctions as bf

# initializations
string_col = rospy.get_param("/hanoi_colors")
hanoi_colors = string_col.split(',')
path_bgr = path_hsv = rospy.get_param("/path_bgr")      # need BGR values to draw current board stat
bgr_baxter = bf.loadBGR(path_bgr)
bridge = CvBridge()
previous_board = None
last_valid_board = None
missing_disk_color = None


# publishes move validity to validMove topic
# 1 = move is correct (cardinality kept, same disk colors across states) [probable]
# 2 = disk is missing (cardinality is not kept) [probable, if fault in CV or user removes]
# 3 = move is not correct


# publishes move validity code (1,2,3)
validMovePub = rospy.Publisher('/hanoi/validMove',Int8)


# publishes last valid board to aid the player when he makes a mistake
lastValidBoardPub = rospy.Publisher('/hanoi/lastValidBoard',FilteredBoard)

# publisher to Baxter's screen
displayImagePub = rospy.Publisher('/robot/xdisplay', Image)


def reinitializeStates(data):
    global previous_board, last_valid_board, missing_disk_color, hanoi_colors

    # if game is reinitialized, clean up variables
    if data.data == 1:
        previous_board = None
        last_valid_board = None
        missing_disk_color = None


def callbackCheck(data):
    global previous_board,current_board,last_valid_board,missing_disk_color,hanoi_colors

    just_started = False
    # if we are at the beginning, initialize previous_board and last_valid_board
    if previous_board is None:
        just_started = True
        previous_board = data
        last_valid_board = data
        rospy.loginfo("Publishing last valid board")
        lastValidBoardPub.publish(last_valid_board)
    # update current board state
    current_board = data

    # SCENARIO I: cardinality is kept
    # nothing changed compared to initial hanoi colors
    # meaning the same colors detected
    if len(current_board.encoded) == len(hanoi_colors):

        # compute the number of moves of each disk from previous to current state
        moves = vf.numDisksMoved(previous_board,current_board)

        # detect which moved
        name_moved = vf.whichMoved(moves)
        valid_move = vf.checkValidity(current_board)

        # SCENARIO Ia: at least one disk moved
        if len(name_moved) >= 1:
            rospy.loginfo("mvValChecker:" + str(valid_move))

            # SCENARIO Ia 1: the move is valid
            if valid_move:
                last_valid_board = current_board    # update last_valid_board
                if not just_started:
                    validMovePub.publish(1)     # tell Game AI node that it can compute next move
                rospy.loginfo("Publishing last valid board")
                lastValidBoardPub.publish(last_valid_board)

                # publish filtered board on Baxter's screen
                imgOnScreen = bf.drawGameState(last_valid_board, bgr_baxter)
                imgOnScreen = bridge.cv2_to_imgmsg(imgOnScreen, "bgr8")
                displayImagePub.publish(imgOnScreen)

            # SCENARIO Ia 2: the move is not valid
            else:
                validMovePub.publish(3)

        # SCENARIO Ib : no disk moved
        else:
            rospy.loginfo("All initial colors detected.")

            if valid_move:
                last_valid_board = current_board  # update last_valid_board
                rospy.loginfo("Publishing last valid board")
                lastValidBoardPub.publish(last_valid_board)

                rospy.loginfo("All colors detected and move is VALID.")
                if not just_started:
                    validMovePub.publish(1)  # tell Game AI node that it can compute next move

                # publish filtered board on Baxter's screen
                imgOnScreen = bf.drawGameState(last_valid_board, bgr_baxter)
                imgOnScreen = bridge.cv2_to_imgmsg(imgOnScreen, "bgr8")
                displayImagePub.publish(imgOnScreen)

            else:
                rospy.loginfo("All colors detected but move is INVALID.")
                validMovePub.publish(3)

    # SCENARIO II: cardinality is not kept - a disk is missing
    elif len(current_board.encoded) < len(hanoi_colors):
        previous_colors = vf.getDiskColor(previous_board)
        current_colors = vf.getDiskColor(current_board)

        colors_previous_str = ""
        for c in previous_colors:
            colors_previous_str = colors_previous_str + " " + c
        rospy.loginfo("Previous colors: " + colors_previous_str)

        colors_current_str = ""
        for c in current_colors:
            colors_current_str = colors_current_str + " " + c
        rospy.loginfo("Current colors: " + colors_current_str)

        color_diff = vf.diskColorDifference(previous_colors, current_colors)
        missing_disk_color = list(color_diff)
        validMovePub.publish(2)

    # SCENARIO III: cardinality is not kept - a disk is added
    else:
        validMovePub.publish(4)

    # when all checks are done, previous_board is the new board
    previous_board = current_board


if __name__ == "__main__":

    # create node
    rospy.init_node('moveValidityChecker', anonymous=True)

    # create subscriber to the game state
    gameRunningSub = rospy.Subscriber('/hanoi/gameRunning', Int8, reinitializeStates)

    # create subscriber to the filtered board topic
    filteredBoardSub = rospy.Subscriber('/hanoi/filteredBoardState', FilteredBoard, callbackCheck)

    # prevents program from exiting, allowing subscribers and publishers to keep operating
    rospy.spin()
