#!/usr/bin/env python

import rospy
from std_msgs.msg import String
from std_msgs.msg import Int8


# initializations
wrong_moves = 0
valid_move = None   # will hold value from topic
feedback_string = "I see a new disk. Terminating game."


# will publish the number of wrong moves made by the player
# adding a disk that was previously removed is considered a wrong move a well
wrongMovesPub = rospy.Publisher('/hanoi/wrongMoves',Int8)

# will publish to speech node
feedbackPub = rospy.Publisher('/hanoi/userFeedback',String)

# will publish to gameRunning topic
gameRunningPub = rospy.Publisher('/hanoi/gameRunning', Int8)

def reinitializeStates(data):
    global wrong_moves, valid_move

    # if game has been reinitialized, clean up variables
    if data.data == 1:
        wrong_moves = 0
        valid_move = None


# update the number of wrong moves, if it was changed by another node (Incorrect move)
def callbackWrongMoves(data):
    global wrong_moves
    wrong_moves = data.data



def callbackAdded(data):
    global valid_move, wrong_moves
    valid_move = data.data

    # disk is added
    if valid_move == 4:

        # tell the player we can see the new disk and we terminate
        rospy.loginfo(feedback_string)
        # feedbackPub.publish(feedback_string)

        # adding a previously removed disk is considered a wrong move
        # wrong_moves += 1
        # rospy.loginfo("Wrong moves is now " + str(wrong_moves))
        # wrongMovesPub.publish(wrong_moves)

        gameRunningPub.publish(4)


if __name__ == "__main__":

    # create node
    rospy.init_node('addedDiskAlgorithm', anonymous=True)

    # create subscriber to the game state
    gameRunningSub = rospy.Subscriber('/hanoi/gameRunning', Int8, reinitializeStates)

    # create subscriber to the valid move topic
    validMoveSub = rospy.Subscriber('/hanoi/validMove', Int8, callbackAdded)

    # create subscriber to the wrong moves topic
    wrongMovesSub = rospy.Subscriber('/hanoi/wrongMoves', Int8, callbackWrongMoves)

    # prevents program from exiting, allowing subscribers and publishers to keep operating
    rospy.spin()
