#!/usr/bin/env python

import rospy
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
import baxter_interface
import cv2
from collections import OrderedDict
import blobFunctions as bf


# filenames
path_bgr = rospy.get_param("/path_bgr")
path_hsv = rospy.get_param("/path_hsv")
path_preprocess = rospy.get_param("/path_preprocess")
string_col = rospy.get_param("/hanoi_colors")


# HSV Baxter
# OrderedDict([('pink', [array([170, 100, 100], dtype=uint8), array([  4, 255, 255], dtype=uint8)]), ('orange', [array([179, 100, 100], dtype=uint8), array([ 13, 255, 255], dtype=uint8)]), ('yellow', [array([ 24, 100, 100], dtype=uint8), array([ 38, 255, 255], dtype=uint8)]), ('dark_green', [array([ 63, 100, 100], dtype=uint8), array([ 77, 255, 255], dtype=uint8)]), ('blue', [array([ 91, 100, 100], dtype=uint8), array([105, 255, 255], dtype=uint8)])])
# BGR Baxter
# OrderedDict([('pink', array([[[ 85,  77, 156]]], dtype=uint8)), ('orange', array([[[ 42,  61, 130]]], dtype=uint8)), ('yellow', array([[[ 87, 183, 181]]], dtype=uint8)), ('dark_green', array([[[ 75, 111,  56]]], dtype=uint8)), ('blue', array([[[158, 134,  71]]], dtype=uint8))])

# take colors from launch file
hanoi_colors = string_col.split(",")
bgr_baxter = OrderedDict()
hsv_baxter = OrderedDict()
preprocess_img = True
hsv_offset = 3  # for hue ranges, default=3, range = [0,10] but upper limit can be extended
white_balance = False
gamma = 1  # for brightness correction, initially = 1 => no effect, limited to [-2,2] but can be changed
calib_start = False
calib_stop = False
calibration_done = False
ellipse_interspace = 15     # space between ellipses (pixel) # 15 initially
ellipse_height = 20         # height of ellipse


# publisher to which we post messages for Baxter's screen
ellipsePub = rospy.Publisher('/robot/xdisplay', Image)


# if left torso button 1 is pressed, we start calibration
def startCalibration(v):
    global calib_start
    if (v == True) and (calib_start == False):
        calib_start = True


# if left torso button 2 is pressed, we stop calibration
def stopCalibration(v):
    global calib_stop, calib_start
    if (v == True) and (calib_start == True) and (calib_stop == False):
        calib_stop = True


# changes gamma parameter
def gammaUpdate(v):
    global gamma
    # middle 127
    if left_torso_nav.wheel == 127:
        gamma = 0
    else:
        gamma = bf.gammaConvert(left_torso_nav.wheel)
    print("Gamma value: %f" % gamma)


# changes white_balance to ON/OFF
def wbUpdate(v):
    global white_balance

    if v == True:
        if white_balance == False:
            white_balance = True
        else:
            white_balance = False
        print(white_balance)


# changes the hsv_offset parameter
def hsvUpdate(v):
    global hsv_offset
    hsv_offset = bf.hsvConvert(left_arm_nav.wheel)

previous_v_space = 5
def interspaceUpdate(v):
    global ellipse_interspace, previous_v_space
    # decrease interspace
    if v < 0:
        ellipse_interspace -= 1
        if ellipse_interspace < 0:
            ellipse_interspace = 0
        print(ellipse_interspace)
    elif v > 0:
        # there should be a limit to this
        ellipse_interspace += 1
        if ellipse_interspace > 30:
            ellipse_interspace = 30
        print(ellipse_interspace)


previous_v_height = 10
def heightUpdate(v):
    global ellipse_height,previous_v_height

    # decrease height
    if v < 0:
        ellipse_height -= 1
        if ellipse_height < 0:
            ellipse_height = 0
        print(ellipse_height)
    elif v > 0:
        # there should be a limit to this
        ellipse_height += 1
        if ellipse_height > 100:
            ellipse_height = 100
        print(ellipse_height)


# callback function for camera subscriber, called by the camera subscriber for every frame.
def calibrateColor(data):
    global calib_start, calib_stop, calibration_done, bgr_baxter, hsv_baxter, hanoi_colors, preproc_calib_img, hsv_offset, gamma, white_balance, ellipse_interspace, ellipse_height
    bridge = CvBridge()

    # Convert incoming image from a ROS image message to a CV image that open CV can process.
    original_image = bridge.imgmsg_to_cv2(data, "bgr8")
    cv2.imshow("Raw Hand Camera Feed", original_image)
    cv2.waitKey(1)
    # boxes_image = original_image.copy()
    boxes_image = original_image

    # preprocess
    if preprocess_img:
        # brightness correction - if image too dark
        # white-balance correction - for more natural colors
        preprocessed_image = bf.preprocessImage(original_image, gamma, white_balance)

    # if calibration has not been done
    if not calibration_done:

        # start calibration
        if calib_start and not calib_stop:

            # compute, don't save masks
            bgr_baxter, out_image_ellipses = bf.getBGRavgColorsFromBaxter(preprocessed_image.copy(), hanoi_colors,
                                                                          False, ellipse_interspace, ellipse_height)
            hsv_baxter = bf.calibrateColors(bgr_baxter, hsv_offset)
            centers_x, centers_y, widths, heights, rotations, found_colors, contours = bf.getBoundingBoxes(
                preprocessed_image.copy(),
                hsv_baxter,
                hanoi_colors)
            stacked_masks, boxes_image = bf.drawBoxes(boxes_image, contours, found_colors)
            out_image_ellipses = bf.showParamOnImg(out_image_ellipses, hsv_offset, white_balance, gamma)

            # show on screen
            cv2.imshow('Ellipses', out_image_ellipses)
            cv2.imshow('Masks', stacked_masks)
            cv2.imshow('Bounding boxes', boxes_image)

            # publish ellipses to Baxter's screen
            out_image_ellipses = bridge.cv2_to_imgmsg(out_image_ellipses, "bgr8")
            ellipsePub.publish(out_image_ellipses)

        # stop calibration, save info
        if calib_start and calib_stop:

            # compute and save masks
            bgr_baxter, out_image_ellipses = bf.getBGRavgColorsFromBaxter(preprocessed_image.copy(), hanoi_colors, True, ellipse_interspace, ellipse_height)
            hsv_baxter = bf.calibrateColors(bgr_baxter, hsv_offset)
            print("HSV Baxter")
            print(hsv_baxter)
            print("BGR Baxter")
            print(bgr_baxter)
            calibration_done = True
            bf.saveHSV(hsv_baxter,path_hsv)  # save HSV values in txt file
            bf.saveBGR(bgr_baxter,path_bgr)  # save BGR values in txt file
            bf.saveProcessParams(white_balance, gamma, path_preprocess)  # save image preprocess params

            cv2.destroyAllWindows()
            cv2.waitKey(100)  # destroy all windows does not work really well
            rospy.loginfo("Color calibration done ...")

    # Display the converted cv image, this is the raw camera feed data.
    # cv2.imshow("Raw Hand Camera Feed", original_image)


if __name__ == '__main__':
    rospy.init_node('colorCalibration', anonymous=True)

    # create subscriber to the right hand camera
    # home: '/cameras2/right_hand_camera/image'
    # uni: '/cameras/right_hand_camera/image'
    camera_sub = rospy.Subscriber("/cameras/right_hand_camera/image", Image, calibrateColor)

    # Baxter buttons
    # https://github.com/RethinkRobotics/baxter_examples/blob/master/scripts/navigator_io.py
    left_torso_nav = baxter_interface.Navigator('torso_left')  # left torso buttons
    right_torso_nav = baxter_interface.Navigator('torso_right')  # right torso buttons
    left_arm_nav = baxter_interface.Navigator('left')  # left arm buttons
    right_arm_nav = baxter_interface.Navigator('right')  # right arm buttons

    # check for left torso button 1 - calibration START
    left_torso_nav.button1_changed.connect(startCalibration)

    # check for left torso button 2 - calibration STOP
    left_torso_nav.button2_changed.connect(stopCalibration)

    # check for left torso wheel changes - changes gamma parameter
    left_torso_nav.wheel_changed.connect(gammaUpdate)

    # check for left arm wheel changes - changes the hsv_offset
    left_arm_nav.wheel_changed.connect(hsvUpdate)

    # check for left arm button 1 press for white balance on-off
    left_arm_nav.button1_changed.connect(wbUpdate)

    # check for right torso wheel changes - changes ellipse height
    right_torso_nav.wheel_changed.connect(heightUpdate)

    # check for right arm wheel changes - changes the space between ellipses
    right_arm_nav.wheel_changed.connect(interspaceUpdate)

    # prevents program from exiting, allowing subscribers and publishers to keep operating
    rospy.spin()
