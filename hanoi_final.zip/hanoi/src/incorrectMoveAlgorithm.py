#!/usr/bin/env python

import rospy
from std_msgs.msg import String
from std_msgs.msg import Int8

# initializations
ALLOWED_WRONG_MOVES = 3
X_SECS = 20     # seconds to wait for move correction
wrong_moves = 0
valid_move = None
timer_X_started = False
timerX = None   # timer to allow correction
feedback_string = "Wrong move. "+str(X_SECS)+" seconds to correct it. See last valid board."


# will publish the number of wrong moves made by the player (since we entered this node)
wrongMovesPub = rospy.Publisher('/hanoi/wrongMoves',Int8)

# will stop game if move is not corrected within an amount of time
# 0 = game is not running / waiting for player to engage
# 1 = game is running
# 2 = game is idle (end game interaction needs to take place)
# 3 = game needs board rearrangement
# 4 = no game setup (board is missing)
gameRunningPub = rospy.Publisher('/hanoi/gameRunning',Int8)


# will publish to speech node to tell user how much time he has
feedbackPub = rospy.Publisher('/hanoi/userFeedback',String)


def reinitializeStates():
    global valid_move, wrong_moves, timer_X_started, timerX
    timer_X_started = False
    timerX = None
    wrong_moves = 0
    valid_move = None


# update the number of wrong moves, if it was changed by another node
def callbackWrongMoves(data):
    global wrong_moves
    wrong_moves = data.data


# after X_SECS, it will check if there was another move made
# if move is still incorrect, will stop the game
def callbackTimer(event):
    global valid_move,timer_X_started,timerX,wrong_moves
    if valid_move == 3:
        rospy.loginfo("Move still incorrect. Terminating game.")
        feedbackPub.publish("Game over.")
        gameRunningPub.publish(3)   # stop game (allow for setup)
        reinitializeStates()        # clean up variables


def callbackMove(data):
    global valid_move,wrong_moves,timer_X_started, timerX
    valid_move = data.data

    # if move is incorrect and no timer was started yet
    if valid_move == 3 and (not timer_X_started):

        # update number of wrong moves
        wrong_moves += 1
        rospy.loginfo("Wrong moves is now "+str(wrong_moves))
        wrongMovesPub.publish(wrong_moves)

        if wrong_moves <= ALLOWED_WRONG_MOVES:

            # warn user that he has X_SECS to correct it and start timer
            rospy.loginfo("Player has "+str(X_SECS)+" seconds to correct.")
            feedbackPub.publish(feedback_string)
            # maybe sleep here
            timerX = rospy.Timer(rospy.Duration(X_SECS), callbackTimer, oneshot=True)
            timer_X_started = True
        else:
            if timerX is not None:
                timerX.shutdown()
            timer_X_started = False


    # if move is corrected/missing and timer was started previously (due to incorrect move)
    elif valid_move != 3 and timer_X_started and timerX is not None:
        timerX.shutdown()
        timer_X_started = False
        rospy.loginfo("Another move was made.")


if __name__ == "__main__":

    # create node
    rospy.init_node('incorrectMoveAlgorithm', anonymous=True)

    # create subscriber to the valid move topic
    validMoveSub = rospy.Subscriber('/hanoi/validMove',Int8,callbackMove)

    # create subscriber to the wrong moves topic
    wrongMovesSub = rospy.Subscriber('/hanoi/wrongMoves',Int8,callbackWrongMoves)

    # prevents program from exiting, allowing subscribers and publishers to keep operating
    rospy.spin()
