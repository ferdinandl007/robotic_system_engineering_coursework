#!/usr/bin/env python

import rospy
from std_msgs.msg import String
from std_msgs.msg import Int8
from std_msgs.msg import Bool


# initializations
Z_SECS = 15     # seconds to wait for user to put disk back VOLUNTARILY
wrong_moves = 0
valid_move = None   # will hold value from topic
timerZ = None
timer_Z_started = False
terminate_string = 'Disk is missing. Terminating game'

# will publish the number of wrong moves made by the player (since we entered this node)
wrongMovesPub = rospy.Publisher('/hanoi/wrongMoves',Int8)

# will publish to speech node
feedbackPub = rospy.Publisher('/hanoi/userFeedback',String)


# 0 = game is not running / waiting for player to engage
# 1 = game is running
# 2 = game is idle (end game interaction needs to take place)
# 3 = game needs board rearrangement
# 4 = no game setup (board is missing)
game_running = None
gameRunningPub = rospy.Publisher('/hanoi/gameRunning', Int8)


def updateGameRunning(data):
    global game_running
    game_running = data.data

    if data.data == 1:
        reinitializeStates()


def reinitializeStates():
    global wrong_moves, valid_move, timerZ, timer_Z_started

    # if the game has been reinitialized, clean up variables
    wrong_moves = 0
    valid_move = None
    if timerZ is not None:
        timerZ.shutdown()
    timerZ = None
    timer_Z_started = False


# update the number of wrong moves, if it was changed by another node (Incorrect move)
def callbackWrongMoves(data):
    global wrong_moves
    wrong_moves = data.data


# Z_SECS after missing disk is detected, it will check if there was another move
def callbackTimerZ(event):
    global valid_move, timer_Z_started

    if game_running == 1:
        # if an incorrect or correct move has been made in the meantime, don't do anything
        if valid_move == 3 or valid_move == 1:
            rospy.loginfo("Player made another move. Continue")
            timer_Z_started = False

        # if disk still missing
        else:
            # terminate game
            feedbackPub.publish(terminate_string)
            rospy.loginfo(terminate_string)
            gameRunningPub.publish(3)   # board needs rearrangement


def callbackMissing(data):
    global valid_move,timerZ,timer_Z_started
    valid_move = data.data

    # if disk is missing and timer to allow to put back VOLUNTARILY has not started
    if valid_move == 2 and (not timer_Z_started):

        # start a timer Z to allow user to put back by himself
        rospy.loginfo("Disk missing. "+str(Z_SECS)+" seconds to put back.")
        timerZ = rospy.Timer(rospy.Duration(Z_SECS), callbackTimerZ, oneshot=True)   # oneshot to fire only once
        timer_Z_started = True

    # if another move made in the meantime, top timer
    elif valid_move == 1 or valid_move == 3:
        if timerZ is not None:
            timerZ.shutdown()
        timer_Z_started = False


if __name__ == "__main__":

    # create node
    rospy.init_node('missingDiskAlgorithm', anonymous=True)

    # create subscriber to the game state
    gameRunningSub = rospy.Subscriber('/hanoi/gameRunning', Int8, updateGameRunning)

    # create subscriber to the valid move topic
    validMoveSub = rospy.Subscriber('/hanoi/validMove', Int8, callbackMissing)

    # create subscriber to the wrong moves topic
    wrongMovesSub = rospy.Subscriber('/hanoi/wrongMoves', Int8, callbackWrongMoves)

    # prevents program from exiting, allowing subscribers and publishers to keep operating
    rospy.spin()
